import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Define user roles
export type UserRole = 'admin' | 'manager' | 'finance' | 'health' | 'hr' | 'sales' | 'worker' | 'viewer';

// Define user object structure
interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
}

// Define auth context value structure
interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  isAuthenticated: boolean;
  hasPermission: (requiredRoles: UserRole[]) => boolean;
}

// Create the auth context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

// Auth provider component
const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is already logged in
  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        setLoading(true);
        // Mock user data for development purposes
        // In a real implementation, this would be replaced with actual API calls
        const mockUser: User = {
          id: 1,
          name: 'Farm Admin',
          email: 'admin@example.com',
          role: 'admin' as UserRole
        };
        setUser(mockUser);

        // Uncomment this for real API implementation
        /*
        // Attempt to get user info if already logged in
        const response = await window.ezsite.apis.getUserInfo();
        if (response.error) {
          // Not logged in or session expired
          setUser(null);
        } else if (response.data) {
          // User is logged in, set user data
          // Map from API user to our User type
          const userData: User = {
            id: response.data.ID,
            name: response.data.Name,
            email: response.data.Email,
            // Default to viewer role if none specified
            role: 'viewer' as UserRole
          };
          setUser(userData);
        }
        */
      } catch (err) {
        console.error('Auth check error:', err);
        // Don't set user to null on error for testing purposes
        // setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);

      // Mock login for development purposes
      // In a real implementation, this would be replaced with actual API calls
      await new Promise((resolve) => setTimeout(resolve, 800)); // Simulate network delay

      // Mock user data based on email
      let mockUser: User;

      if (email === 'admin@example.com') {
        mockUser = {
          id: 1,
          name: 'Farm Admin',
          email: 'admin@example.com',
          role: 'admin' as UserRole
        };
      } else if (email === 'manager@example.com') {
        mockUser = {
          id: 2,
          name: 'Farm Manager',
          email: 'manager@example.com',
          role: 'manager' as UserRole
        };
      } else {
        mockUser = {
          id: 3,
          name: 'Farm Worker',
          email: email,
          role: 'worker' as UserRole
        };
      }

      setUser(mockUser);

      // Real API implementation (commented out for now)
      /*
      const response = await window.ezsite.apis.login({ email, password });
      
      if (response.error) {
        throw new Error(response.error);
      }
      
      // Get user info after successful login
      const userResponse = await window.ezsite.apis.getUserInfo();
      
      if (userResponse.error) {
        throw new Error(userResponse.error);
      }
      
      // Set user data
      const userData: User = {
        id: userResponse.data.ID,
        name: userResponse.data.Name,
        email: userResponse.data.Email,
        // Default to viewer role if none specified
        role: 'viewer' as UserRole
      };
      
      setUser(userData);
      */
    } catch (err: any) {
      setError(err.message || 'Login failed');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    try {
      setLoading(true);

      // Mock logout for development purposes
      await new Promise((resolve) => setTimeout(resolve, 500)); // Simulate network delay
      setUser(null);

      // Real API implementation (commented out for now)
      /*
      const response = await window.ezsite.apis.logout();
      
      if (response.error) {
        throw new Error(response.error);
      }
      
      setUser(null);
      */
    } catch (err: any) {
      setError(err.message || 'Logout failed');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Function to check if user has required permission
  const hasPermission = (requiredRoles: UserRole[]): boolean => {
    if (!user) return false;

    // Admin has access to everything
    if (user.role === 'admin') return true;

    // Check if user's role is in the required roles
    return requiredRoles.includes(user.role);
  };

  const value = {
    user,
    loading,
    error,
    login,
    logout,
    isAuthenticated: !!user,
    hasPermission
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export default AuthProvider;