import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

interface AlertsNotificationsProps {
  title: string;
  className?: string;
}

const AlertsNotifications = ({ title, className }: AlertsNotificationsProps) => {
  return (
    <Card className={className}>
      <CardHeader className="pb-2 flex flex-row justify-between items-center">
        <CardTitle className="text-lg font-medium flex items-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-5 w-5" data-id="8bzrj7jf7" data-path="src/components/dashboard/AlertsNotifications.tsx">

            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" data-id="mj8848vts" data-path="src/components/dashboard/AlertsNotifications.tsx" />
            <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" data-id="j7mssn41h" data-path="src/components/dashboard/AlertsNotifications.tsx" />
          </svg>
          {title}
        </CardTitle>
        <div className="flex items-center justify-center rounded-full bg-gray-100 w-6 h-6 text-xs font-medium" data-id="diwvlar37" data-path="src/components/dashboard/AlertsNotifications.tsx">
          0
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-center py-8 text-gray-500 text-sm" data-id="10h2pan03" data-path="src/components/dashboard/AlertsNotifications.tsx">
          <p data-id="xdbmbd4o7" data-path="src/components/dashboard/AlertsNotifications.tsx">No notifications yet</p>
        </div>
      </CardContent>
    </Card>);

};

export default AlertsNotifications;