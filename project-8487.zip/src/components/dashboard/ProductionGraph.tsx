import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

interface ProductionGraphProps {
  title: string;
  className?: string;
}

const ProductionGraph = ({ title, className }: ProductionGraphProps) => {
  // This is a simplified representation of the graph shown in the image
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[250px] w-full relative" data-id="3w7tfzgjf" data-path="src/components/dashboard/ProductionGraph.tsx">
          {/* SVG Line Chart */}
          <svg viewBox="0 0 620 250" className="w-full h-full" data-id="mgbzgyas2" data-path="src/components/dashboard/ProductionGraph.tsx">
            {/* X-axis labels */}
            <text x="10" y="240" className="text-xs text-gray-500" data-id="lxpo65l9o" data-path="src/components/dashboard/ProductionGraph.tsx">Jan</text>
            <text x="70" y="240" className="text-xs text-gray-500" data-id="wu37h84ly" data-path="src/components/dashboard/ProductionGraph.tsx">Feb</text>
            <text x="130" y="240" className="text-xs text-gray-500" data-id="gs11bwgil" data-path="src/components/dashboard/ProductionGraph.tsx">Mar</text>
            <text x="190" y="240" className="text-xs text-gray-500" data-id="8w3179x8t" data-path="src/components/dashboard/ProductionGraph.tsx">Apr</text>
            <text x="250" y="240" className="text-xs text-gray-500" data-id="xyvn28ffg" data-path="src/components/dashboard/ProductionGraph.tsx">May</text>
            <text x="310" y="240" className="text-xs text-gray-500" data-id="tiw9381vz" data-path="src/components/dashboard/ProductionGraph.tsx">Jun</text>
            <text x="370" y="240" className="text-xs text-gray-500" data-id="2o6amct6h" data-path="src/components/dashboard/ProductionGraph.tsx">Jul</text>
            <text x="430" y="240" className="text-xs text-gray-500" data-id="mgrrh5bax" data-path="src/components/dashboard/ProductionGraph.tsx">Aug</text>
            <text x="490" y="240" className="text-xs text-gray-500" data-id="ttzm5erze" data-path="src/components/dashboard/ProductionGraph.tsx">Sep</text>
            <text x="550" y="240" className="text-xs text-gray-500" data-id="r4t44yiuz" data-path="src/components/dashboard/ProductionGraph.tsx">Oct</text>
            <text x="610" y="240" className="text-xs text-gray-500" data-id="qkfekhrfu" data-path="src/components/dashboard/ProductionGraph.tsx">Nov</text>
            <text x="670" y="240" className="text-xs text-gray-500" data-id="gh8u65l1s" data-path="src/components/dashboard/ProductionGraph.tsx">Dec</text>
            
            {/* Y-axis labels */}
            <text x="5" y="20" className="text-xs text-gray-500" data-id="ayqnwnemo" data-path="src/components/dashboard/ProductionGraph.tsx">60000</text>
            <text x="5" y="80" className="text-xs text-gray-500" data-id="yhrqw4ax5" data-path="src/components/dashboard/ProductionGraph.tsx">45000</text>
            <text x="5" y="140" className="text-xs text-gray-500" data-id="y9ggfrltc" data-path="src/components/dashboard/ProductionGraph.tsx">30000</text>
            <text x="5" y="200" className="text-xs text-gray-500" data-id="y0rmo4tuz" data-path="src/components/dashboard/ProductionGraph.tsx">15000</text>
            <text x="10" y="220" className="text-xs text-gray-500" data-id="evni9h2qf" data-path="src/components/dashboard/ProductionGraph.tsx">0</text>
            
            {/* Line chart */}
            <path
              d="M30,80 C50,70 70,80 90,75 C110,72 130,80 150,70 C170,60 190,65 210,55 C230,50 250,55 270,52 C290,50 310,48 330,50 C350,52 370,50 390,52 C410,55 430,52 450,50 C470,48 490,52 510,55 C530,60 550,52 570,100 C590,180 600,200 610,220"
              fill="none"
              stroke="#4ade80"
              strokeWidth="2" data-id="ctjelhtvs" data-path="src/components/dashboard/ProductionGraph.tsx" />

            
            {/* Area under the line */}
            <path
              d="M30,80 C50,70 70,80 90,75 C110,72 130,80 150,70 C170,60 190,65 210,55 C230,50 250,55 270,52 C290,50 310,48 330,50 C350,52 370,50 390,52 C410,55 430,52 450,50 C470,48 490,52 510,55 C530,60 550,52 570,100 C590,180 600,200 610,220 V220 H30 Z"
              fill="url(#gradient)"
              opacity="0.2" data-id="guglj9vqr" data-path="src/components/dashboard/ProductionGraph.tsx" />

            
            {/* Gradient definition */}
            <defs data-id="r1abnyv2n" data-path="src/components/dashboard/ProductionGraph.tsx">
              <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%" data-id="36lbfzsy6" data-path="src/components/dashboard/ProductionGraph.tsx">
                <stop offset="0%" stopColor="#4ade80" stopOpacity="0.8" data-id="9aci7affn" data-path="src/components/dashboard/ProductionGraph.tsx" />
                <stop offset="100%" stopColor="#4ade80" stopOpacity="0.1" data-id="mre0il6no" data-path="src/components/dashboard/ProductionGraph.tsx" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </CardContent>
    </Card>);

};

export default ProductionGraph;