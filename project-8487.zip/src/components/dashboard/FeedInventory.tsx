import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface FeedTypeProps {
  label: string;
  current: number;
  max: number;
}

const FeedType = ({ label, current, max }: FeedTypeProps) => {
  const percentage = current / max * 100;

  return (
    <div className="space-y-2" data-id="cn66p5v3b" data-path="src/components/dashboard/FeedInventory.tsx">
      <div className="flex justify-between" data-id="4rzqjc2y6" data-path="src/components/dashboard/FeedInventory.tsx">
        <span className="text-sm font-medium" data-id="3x7pw87mt" data-path="src/components/dashboard/FeedInventory.tsx">{label}</span>
        <span className="text-sm text-gray-500" data-id="d33cw2oa6" data-path="src/components/dashboard/FeedInventory.tsx">
          {current} kg / {max} kg
        </span>
      </div>
      <Progress
        value={percentage}
        className="h-2.5"
        style={{
          backgroundColor: percentage < 30 ? '#fee2e2' : '#f3f4f6'
        }}>

        <div
          className="h-full bg-green-500 rounded-full transition-all"
          style={{
            width: `${percentage}%`,
            backgroundColor: percentage < 30 ? '#ef4444' : '#22c55e'
          }} data-id="jqn9bvl8x" data-path="src/components/dashboard/FeedInventory.tsx" />

      </Progress>
    </div>);

};

interface FeedInventoryProps {
  title: string;
  subtitle: string;
  className?: string;
}

const FeedInventory = ({ title, subtitle, className }: FeedInventoryProps) => {
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
        <p className="text-sm text-gray-500" data-id="en2dz0hhv" data-path="src/components/dashboard/FeedInventory.tsx">{subtitle}</p>
      </CardHeader>
      <CardContent className="space-y-6">
        <FeedType label="Starter Feed" current={1250} max={5000} />
        <FeedType label="Layer Feed" current={3850} max={5000} />
        <FeedType label="Grower Feed" current={2150} max={5000} />
        
        <div className="grid grid-cols-2 gap-4 pt-4" data-id="4cr7qaqsk" data-path="src/components/dashboard/FeedInventory.tsx">
          <div className="space-y-1" data-id="zdlzzfb4k" data-path="src/components/dashboard/FeedInventory.tsx">
            <span className="text-sm text-gray-500" data-id="8t2l8t7q6" data-path="src/components/dashboard/FeedInventory.tsx">Daily Consumption</span>
            <p className="text-xl font-bold" data-id="nbfyppdg2" data-path="src/components/dashboard/FeedInventory.tsx">620 kg</p>
          </div>
          <div className="space-y-1" data-id="rnamxcuno" data-path="src/components/dashboard/FeedInventory.tsx">
            <span className="text-sm text-gray-500" data-id="0qn0f10ct" data-path="src/components/dashboard/FeedInventory.tsx">Weekly Consumption</span>
            <p className="text-xl font-bold" data-id="lgnoooscj" data-path="src/components/dashboard/FeedInventory.tsx">4340 kg</p>
          </div>
        </div>
        
        <div className="pt-2" data-id="kptt7jh7a" data-path="src/components/dashboard/FeedInventory.tsx">
          <span className="text-sm text-gray-500" data-id="50zvlkisj" data-path="src/components/dashboard/FeedInventory.tsx">Estimated days until next order needed:</span>
          <p className="text-lg font-bold" data-id="0zld6676y" data-path="src/components/dashboard/FeedInventory.tsx">11 days</p>
        </div>
      </CardContent>
    </Card>);

};

export default FeedInventory;