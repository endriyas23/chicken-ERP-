import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface MetricsCardProps {
  title: string;
  value: string | number;
  description: string;
  change?: {
    value: string;
    type: "increase" | "decrease" | "neutral";
    period: string;
  };
  icon?: React.ReactNode;
  className?: string;
}

const MetricsCard = ({
  title,
  value,
  description,
  change,
  icon,
  className
}: MetricsCardProps) => {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-500">{title}</CardTitle>
        {icon && <div className="h-4 w-4 text-gray-500" data-id="8mcaiw28z" data-path="src/components/dashboard/MetricsCard.tsx">{icon}</div>}
      </CardHeader>
      <CardContent>
        <div className="flex flex-col space-y-1.5" data-id="59be88u4m" data-path="src/components/dashboard/MetricsCard.tsx">
          <div className="text-2xl font-bold" data-id="mkts9z4z4" data-path="src/components/dashboard/MetricsCard.tsx">{value}</div>
          <p className="text-xs text-gray-500" data-id="p4qoxgo8v" data-path="src/components/dashboard/MetricsCard.tsx">{description}</p>
          {change &&
          <div className="flex items-center pt-1" data-id="ssv8lcqqw" data-path="src/components/dashboard/MetricsCard.tsx">
              <span
              className={cn(
                "flex items-center text-xs",
                change.type === "increase" && "text-green-500",
                change.type === "decrease" && "text-red-500",
                change.type === "neutral" && "text-gray-500"
              )} data-id="qr6g20yhf" data-path="src/components/dashboard/MetricsCard.tsx">

                {change.type === "increase" &&
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1 h-3 w-3" data-id="z4l1zl2hi" data-path="src/components/dashboard/MetricsCard.tsx">

                    <polyline points="18 15 12 9 6 15" data-id="pl61ab53r" data-path="src/components/dashboard/MetricsCard.tsx" />
                  </svg>
              }
                {change.type === "decrease" &&
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1 h-3 w-3" data-id="h5qot8yel" data-path="src/components/dashboard/MetricsCard.tsx">

                    <polyline points="6 9 12 15 18 9" data-id="1ypyiyhc0" data-path="src/components/dashboard/MetricsCard.tsx" />
                  </svg>
              }
                {change.value} {change.period}
              </span>
            </div>
          }
        </div>
      </CardContent>
    </Card>);

};

export default MetricsCard;