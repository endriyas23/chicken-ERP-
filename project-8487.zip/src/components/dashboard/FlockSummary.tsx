import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

interface FlockSummaryProps {
  title: string;
  subtitle: string;
  className?: string;
}

const FlockSummary = ({ title, subtitle, className }: FlockSummaryProps) => {
  return (
    <Card className={className}>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
        <p className="text-sm text-gray-500" data-id="dwgouc4h6" data-path="src/components/dashboard/FlockSummary.tsx">{subtitle}</p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4" data-id="s9wnpmd13" data-path="src/components/dashboard/FlockSummary.tsx">
          <div data-id="9nplg23bk" data-path="src/components/dashboard/FlockSummary.tsx">
            <h3 className="text-sm font-medium mb-4" data-id="kye8xvm74" data-path="src/components/dashboard/FlockSummary.tsx">Breed Distribution</h3>
            <div className="relative w-full h-[150px]" data-id="rb1ok93bx" data-path="src/components/dashboard/FlockSummary.tsx">
              {/* Simple SVG Pie Chart */}
              <svg viewBox="0 0 100 100" className="w-full h-full" data-id="8ka4i9yx2" data-path="src/components/dashboard/FlockSummary.tsx">
                <circle cx="50" cy="50" r="45" fill="#65a30d" data-id="h0n6tpspv" data-path="src/components/dashboard/FlockSummary.tsx" />
                <path
                  d="M50,50 L50,5 A45,45 0 0,1 88,73 z"
                  fill="#84cc16" data-id="xa7669lu0" data-path="src/components/dashboard/FlockSummary.tsx" />

                <path
                  d="M50,50 L88,73 A45,45 0 0,1 12,73 z"
                  fill="#a3e635" data-id="e4zt77swu" data-path="src/components/dashboard/FlockSummary.tsx" />

                <path
                  d="M50,50 L12,73 A45,45 0 0,1 50,5 z"
                  fill="#4ade80" data-id="i3c6opw8a" data-path="src/components/dashboard/FlockSummary.tsx" />

              </svg>
              
              <div className="absolute bottom-0 left-0 text-xs text-center w-full" data-id="kex7jqv5v" data-path="src/components/dashboard/FlockSummary.tsx">
                Plymouth Rock
              </div>
            </div>
          </div>
          
          <div data-id="rhkugkzl2" data-path="src/components/dashboard/FlockSummary.tsx">
            <h3 className="text-sm font-medium mb-4" data-id="33qfs15g3" data-path="src/components/dashboard/FlockSummary.tsx">Age Distribution</h3>
            <div className="relative w-full h-[150px]" data-id="tyminok9m" data-path="src/components/dashboard/FlockSummary.tsx">
              {/* Simple SVG Pie Chart for Age Distribution */}
              <svg viewBox="0 0 100 100" className="w-full h-full" data-id="rid78x15i" data-path="src/components/dashboard/FlockSummary.tsx">
                <path
                  d="M50,50 L50,5 A45,45 0 0,1 95,50 z"
                  fill="#65a30d" data-id="ep3s3twh5" data-path="src/components/dashboard/FlockSummary.tsx" />

                <path
                  d="M50,50 L95,50 A45,45 0 0,1 78,85 z"
                  fill="#84cc16" data-id="82grhv1d0" data-path="src/components/dashboard/FlockSummary.tsx" />

                <path
                  d="M50,50 L78,85 A45,45 0 0,1 22,85 z"
                  fill="#a3e635" data-id="49j6ooohs" data-path="src/components/dashboard/FlockSummary.tsx" />

                <path
                  d="M50,50 L22,85 A45,45 0 0,1 5,50 z"
                  fill="#bef264" data-id="3hq3fbhep" data-path="src/components/dashboard/FlockSummary.tsx" />

                <path
                  d="M50,50 L5,50 A45,45 0 0,1 50,5 z"
                  fill="#d9f99d" data-id="u6sorisjv" data-path="src/components/dashboard/FlockSummary.tsx" />

              </svg>
              
              <div className="absolute right-0 top-2 text-xs space-y-1" data-id="unnjuwvc2" data-path="src/components/dashboard/FlockSummary.tsx">
                <div className="flex items-center gap-1" data-id="547y41xvl" data-path="src/components/dashboard/FlockSummary.tsx">
                  <div className="w-3 h-3 bg-[#65a30d]" data-id="cym8zucpd" data-path="src/components/dashboard/FlockSummary.tsx"></div>
                  <span data-id="nh3c9q1c8" data-path="src/components/dashboard/FlockSummary.tsx">0-12 weeks</span>
                </div>
                <div className="flex items-center gap-1" data-id="61seb8bbs" data-path="src/components/dashboard/FlockSummary.tsx">
                  <div className="w-3 h-3 bg-[#84cc16]" data-id="hvzxxuw6z" data-path="src/components/dashboard/FlockSummary.tsx"></div>
                  <span data-id="l8yhb9o3q" data-path="src/components/dashboard/FlockSummary.tsx">13-24 weeks</span>
                </div>
                <div className="flex items-center gap-1" data-id="e9sjxpnk4" data-path="src/components/dashboard/FlockSummary.tsx">
                  <div className="w-3 h-3 bg-[#a3e635]" data-id="qv015ig15" data-path="src/components/dashboard/FlockSummary.tsx"></div>
                  <span data-id="zxc7xu5x0" data-path="src/components/dashboard/FlockSummary.tsx">25-52 weeks</span>
                </div>
                <div className="flex items-center gap-1" data-id="yai6nge6i" data-path="src/components/dashboard/FlockSummary.tsx">
                  <div className="w-3 h-3 bg-[#bef264]" data-id="a6qv4xrwo" data-path="src/components/dashboard/FlockSummary.tsx"></div>
                  <span data-id="vddv4se8d" data-path="src/components/dashboard/FlockSummary.tsx">+52 weeks</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>);

};

export default FlockSummary;