import React from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  href: string;
  active?: boolean;
}

const SidebarItem = ({ icon, label, href, active }: SidebarItemProps) => {
  return (
    <Link
      to={href}
      className={cn(
        "flex items-center gap-3 px-3 py-2 rounded-md transition-colors duration-200",
        active ? "bg-gray-100" : "hover:bg-gray-100"
      )}>

      <div className="w-5 h-5 flex items-center justify-center" data-id="b0u6zaggx" data-path="src/components/Sidebar.tsx">{icon}</div>
      <span className="text-sm font-medium" data-id="ldroccpeo" data-path="src/components/Sidebar.tsx">{label}</span>
    </Link>);

};

const Sidebar = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  return (
    <div className="w-[205px] border-r flex flex-col h-screen bg-white" data-id="mf5c36p6n" data-path="src/components/Sidebar.tsx">
      <div className="p-4 border-b" data-id="lo4r9ilew" data-path="src/components/Sidebar.tsx">
        <h1 className="text-lg font-bold text-green-600" data-id="7pch1n6ab" data-path="src/components/Sidebar.tsx">Poultry Manager</h1>
        <p className="text-xs text-gray-500" data-id="32ntwhdin" data-path="src/components/Sidebar.tsx">awra chickens</p>
      </div>
      
      <nav className="flex-1 py-4 px-2 space-y-1" data-id="rlhi6r8c2" data-path="src/components/Sidebar.tsx">
        <SidebarItem
          href="/"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="nbp9i8q66" data-path="src/components/Sidebar.tsx"><rect width="7" height="9" x="3" y="3" rx="1" data-id="xqlujb4z6" data-path="src/components/Sidebar.tsx" /><rect width="7" height="5" x="14" y="3" rx="1" data-id="0mx5d5o9i" data-path="src/components/Sidebar.tsx" /><rect width="7" height="9" x="14" y="12" rx="1" data-id="xry1eitdr" data-path="src/components/Sidebar.tsx" /><rect width="7" height="5" x="3" y="16" rx="1" data-id="rpisqtve2" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Dashboard"
          active={currentPath === "/"} />

        
        <SidebarItem
          href="/flocks"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="hlu25fln9" data-path="src/components/Sidebar.tsx"><path d="M17 6.1H3M21 12.1H3M21 18.1H3" data-id="mrjmxl41a" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Flocks"
          active={currentPath.startsWith("/flocks")} />

        
        <SidebarItem
          href="/feed"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="b1u62mdtn" data-path="src/components/Sidebar.tsx"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" data-id="hfjet3166" data-path="src/components/Sidebar.tsx" /><path d="M7 2v20" data-id="muu4a5xqx" data-path="src/components/Sidebar.tsx" /><path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Z" data-id="m5tjun7ok" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Feed & Nutrition"
          active={currentPath.startsWith("/feed")} />

        
        <SidebarItem
          href="/egg-production"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="vz436r54h" data-path="src/components/Sidebar.tsx"><circle cx="12" cy="12" r="10" data-id="dtblklwrv" data-path="src/components/Sidebar.tsx" /><path d="M12 6v6l4 2" data-id="mqx9o4hw1" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Egg Production"
          active={currentPath.startsWith("/egg-production")} />

        
        <SidebarItem
          href="/health"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="242pk7qt3" data-path="src/components/Sidebar.tsx"><path d="M22 12h-4l-3 9L9 3l-3 9H2" data-id="2v7873q2r" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Health"
          active={currentPath.startsWith("/health")} />

        
        <SidebarItem
          href="/sales"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="ffie3k60m" data-path="src/components/Sidebar.tsx"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" data-id="ccwmyvhe7" data-path="src/components/Sidebar.tsx" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" data-id="fwbc0zwjf" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Sales"
          active={currentPath.startsWith("/sales")} />

        
        <SidebarItem
          href="/inventory"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="s956z341x" data-path="src/components/Sidebar.tsx"><path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" data-id="5j5a0stz4" data-path="src/components/Sidebar.tsx" /><path d="M4 6v12c0 1.1.9 2 2 2h14v-4" data-id="3j61vlsmz" data-path="src/components/Sidebar.tsx" /><path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z" data-id="aweh9xlmf" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Inventory"
          active={currentPath.startsWith("/inventory")} />

        
        <SidebarItem
          href="/staff"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="n38a7y06k" data-path="src/components/Sidebar.tsx"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" data-id="yjm71utqc" data-path="src/components/Sidebar.tsx" /><circle cx="9" cy="7" r="4" data-id="th3e4ql43" data-path="src/components/Sidebar.tsx" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" data-id="riz3bemki" data-path="src/components/Sidebar.tsx" /><path d="M16 3.13a4 4 0 0 1 0 7.75" data-id="76wpoh9s1" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Staff"
          active={currentPath.startsWith("/staff")} />

        
        <SidebarItem
          href="/finance"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="nwxdpnho6" data-path="src/components/Sidebar.tsx"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" data-id="dfpdlm58s" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Finance"
          active={currentPath.startsWith("/finance")} />

        
        <SidebarItem
          href="/settings"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="z07fouh3q" data-path="src/components/Sidebar.tsx"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" data-id="v5ega3cjf" data-path="src/components/Sidebar.tsx" /><circle cx="12" cy="12" r="3" data-id="xw7wzuuyt" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Settings"
          active={currentPath.startsWith("/settings")} />

      </nav>
      
      <div className="mt-auto p-4 border-t" data-id="16m5pynfc" data-path="src/components/Sidebar.tsx">
        <SidebarItem
          href="/logout"
          icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5" data-id="2tl4h79lq" data-path="src/components/Sidebar.tsx"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" data-id="8onpnccjo" data-path="src/components/Sidebar.tsx" /><polyline points="16 17 21 12 16 7" data-id="5mlkjo5ry" data-path="src/components/Sidebar.tsx" /><line x1="21" y1="12" x2="9" y2="12" data-id="ekxueqh62" data-path="src/components/Sidebar.tsx" /></svg>}
          label="Sign Out"
          active={false} />

      </div>
    </div>);

};

export default Sidebar;