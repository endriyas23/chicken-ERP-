import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import {
  ChevronLeft,
  LayoutDashboard,
  Users,
  Egg,
  HeartPulse,
  ShoppingCart,
  BarChart3,
  Warehouse,
  DollarSign,
  UserCog,
  Settings,
  Menu,
  LogOut,
  X } from
'lucide-react';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const navItems = [
  { icon: <LayoutDashboard size={20} />, label: 'Dashboard', path: '/dashboard' },
  { icon: <Users size={20} />, label: 'Flocks', path: '/flocks' },
  { icon: <ShoppingCart size={20} />, label: 'Feed', path: '/feed' },
  { icon: <HeartPulse size={20} />, label: 'Health', path: '/health' },
  { icon: <Egg size={20} />, label: 'Production', path: '/production' },
  { icon: <BarChart3 size={20} />, label: 'Sales', path: '/sales' },
  { icon: <Warehouse size={20} />, label: 'Inventory', path: '/inventory' },
  { icon: <DollarSign size={20} />, label: 'Finance', path: '/finance' },
  { icon: <UserCog size={20} />, label: 'HR', path: '/hr' },
  { icon: <Settings size={20} />, label: 'Settings', path: '/settings' }];


  const NavLink = ({ item }: {item: typeof navItems[0];}) =>
  <Button
    variant="ghost"
    className={cn(
      "w-full justify-start gap-2",
      window.location.pathname === item.path && "bg-muted"
    )}
    onClick={() => navigate(item.path)}>

      {item.icon}
      {!collapsed && <span data-id="z4dx1h8zc" data-path="src/components/Layout.tsx">{item.label}</span>}
    </Button>;


  const Sidebar = () =>
  <aside
    className={cn(
      "flex flex-col h-screen bg-background border-r transition-all duration-300",
      collapsed ? "w-16" : "w-64"
    )} data-id="toee0o1a0" data-path="src/components/Layout.tsx">

      <div className="p-4 flex justify-between items-center border-b" data-id="46fbq3gek" data-path="src/components/Layout.tsx">
        {!collapsed && <h1 className="font-bold text-xl" data-id="cofd363pw" data-path="src/components/Layout.tsx">Chicken Farm ERP</h1>}
        <Button
        variant="ghost"
        size="icon"
        onClick={() => setCollapsed(!collapsed)}
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>

          <ChevronLeft className={cn("transition-all", collapsed && "rotate-180")} />
        </Button>
      </div>

      <div className="flex-1 overflow-auto py-4 space-y-2 px-2" data-id="mabvmuv7o" data-path="src/components/Layout.tsx">
        {navItems.map((item, index) =>
      <NavLink key={index} item={item} />
      )}
      </div>

      <div className="p-4 border-t" data-id="d95eaqom2" data-path="src/components/Layout.tsx">
        <Button
        variant="ghost"
        className="w-full justify-start gap-2 text-destructive"
        onClick={handleLogout}>

          <LogOut size={20} />
          {!collapsed && <span data-id="qxdsoa2nh" data-path="src/components/Layout.tsx">Logout</span>}
        </Button>
      </div>
    </aside>;


  const MobileSidebar = () =>
  <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="lg:hidden">
          <Menu />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="p-0 w-72">
        <div className="p-4 flex justify-between items-center border-b" data-id="41j74m4od" data-path="src/components/Layout.tsx">
          <h1 className="font-bold text-xl" data-id="nskmhh7su" data-path="src/components/Layout.tsx">Chicken Farm ERP</h1>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <X />
            </Button>
          </SheetTrigger>
        </div>
        <div className="flex-1 overflow-auto py-4 space-y-2 px-4" data-id="ffz8nqb51" data-path="src/components/Layout.tsx">
          {navItems.map((item, index) =>
        <Button
          key={index}
          variant="ghost"
          className="w-full justify-start gap-2"
          onClick={() => navigate(item.path)}>

              {item.icon}
              <span data-id="4uobpi3uy" data-path="src/components/Layout.tsx">{item.label}</span>
            </Button>
        )}
        </div>
        <div className="p-4 border-t" data-id="z49z67t8c" data-path="src/components/Layout.tsx">
          <Button
          variant="ghost"
          className="w-full justify-start gap-2 text-destructive"
          onClick={handleLogout}>

            <LogOut size={20} />
            <span data-id="6j92grxm9" data-path="src/components/Layout.tsx">Logout</span>
          </Button>
        </div>
      </SheetContent>
    </Sheet>;


  return (
    <div className="flex h-screen overflow-hidden" data-id="y3inizshg" data-path="src/components/Layout.tsx">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block" data-id="1b0i36dzb" data-path="src/components/Layout.tsx">
        <Sidebar />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden" data-id="e1y7oj1no" data-path="src/components/Layout.tsx">
        {/* Top Header */}
        <header className="h-16 border-b flex items-center justify-between px-4" data-id="ax2fzltgz" data-path="src/components/Layout.tsx">
          <div className="flex items-center gap-4" data-id="cswrf0fbu" data-path="src/components/Layout.tsx">
            <MobileSidebar />
            <h1 className="font-bold text-lg lg:text-xl" data-id="ra1u9d9t8" data-path="src/components/Layout.tsx">Chicken Farm ERP</h1>
          </div>
          <div className="flex items-center gap-2" data-id="6955fv3nt" data-path="src/components/Layout.tsx">
            <span className="text-sm font-medium" data-id="1wbcmtwoh" data-path="src/components/Layout.tsx">{user?.name}</span>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-4" data-id="2dimubwiz" data-path="src/components/Layout.tsx">
          {children}
        </main>
      </div>
    </div>);

};

export default Layout;