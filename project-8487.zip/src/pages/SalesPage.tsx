import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Plus, Users, Calendar as CalendarIcon, Trash2, Edit, Search, RotateCcw, FileText, PackageCheck, PackageX } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const SalesPage: React.FC = () => {
  const { toast } = useToast();
  const [orders, setOrders] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [loadingCustomers, setLoadingCustomers] = useState(false);
  const [orderDialog, setOrderDialog] = useState(false);
  const [customerDialog, setCustomerDialog] = useState(false);
  const [ordersPage, setOrdersPage] = useState(1);
  const [customersPage, setCustomersPage] = useState(1);
  const [totalOrders, setTotalOrders] = useState(0);
  const [totalCustomers, setTotalCustomers] = useState(0);
  const [editingOrder, setEditingOrder] = useState<any>(null);
  const [editingCustomer, setEditingCustomer] = useState<any>(null);
  const pageSize = 10;

  // Form state for new order
  const [newOrder, setNewOrder] = useState({
    order_date: new Date(),
    customer_id: 0,
    product_type: 'eggs',
    quantity: 0,
    unit_price: 0,
    total_amount: 0,
    payment_status: 'unpaid',
    delivery_date: new Date(new Date().setDate(new Date().getDate() + 1)),
    delivery_status: 'pending',
    notes: ''
  });

  // Form state for new customer
  const [newCustomer, setNewCustomer] = useState({
    customer_name: '',
    contact_person: '',
    phone: '',
    email: '',
    address: '',
    customer_type: 'consumer',
    notes: ''
  });

  // Load orders
  const loadOrders = async () => {
    setLoadingOrders(true);
    try {
      const response = await window.ezsite.apis.tablePage(5010, {
        PageNo: ordersPage,
        PageSize: pageSize,
        OrderByField: "order_date",
        IsAsc: false
      });

      if (response.error) throw response.error;

      setOrders(response.data.List);
      setTotalOrders(response.data.VirtualCount);
    } catch (error) {
      console.error('Error loading orders:', error);
      toast({
        title: 'Error',
        description: `Failed to load orders: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setLoadingOrders(false);
    }
  };

  // Load customers
  const loadCustomers = async () => {
    setLoadingCustomers(true);
    try {
      const response = await window.ezsite.apis.tablePage(5009, {
        PageNo: customersPage,
        PageSize: pageSize,
        OrderByField: "customer_name",
        IsAsc: true
      });

      if (response.error) throw response.error;

      setCustomers(response.data.List);
      setTotalCustomers(response.data.VirtualCount);
    } catch (error) {
      console.error('Error loading customers:', error);
      toast({
        title: 'Error',
        description: `Failed to load customers: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setLoadingCustomers(false);
    }
  };

  // Add or update order
  const saveOrder = async () => {
    try {
      // Calculate total amount if quantity or unit price changes
      const calculatedTotal = newOrder.quantity * newOrder.unit_price;
      const orderData = {
        ...newOrder,
        total_amount: calculatedTotal
      };

      let response;
      if (editingOrder) {
        response = await window.ezsite.apis.tableUpdate(5010, {
          ...orderData,
          ID: editingOrder.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5010, orderData);
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingOrder ? 'Order updated successfully' : 'New order created'
      });

      setOrderDialog(false);
      setEditingOrder(null);
      resetOrderForm();
      loadOrders();
    } catch (error) {
      console.error('Error saving order:', error);
      toast({
        title: 'Error',
        description: `Failed to save order: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Add or update customer
  const saveCustomer = async () => {
    try {
      let response;
      if (editingCustomer) {
        response = await window.ezsite.apis.tableUpdate(5009, {
          ...newCustomer,
          ID: editingCustomer.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5009, newCustomer);
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingCustomer ? 'Customer updated successfully' : 'New customer added'
      });

      setCustomerDialog(false);
      setEditingCustomer(null);
      resetCustomerForm();
      loadCustomers();
    } catch (error) {
      console.error('Error saving customer:', error);
      toast({
        title: 'Error',
        description: `Failed to save customer: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete order
  const deleteOrder = async (id: number) => {
    if (!confirm('Are you sure you want to delete this order?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5010, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Order deleted successfully'
      });

      loadOrders();
    } catch (error) {
      console.error('Error deleting order:', error);
      toast({
        title: 'Error',
        description: `Failed to delete order: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete customer
  const deleteCustomer = async (id: number) => {
    if (!confirm('Are you sure you want to delete this customer?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5009, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Customer deleted successfully'
      });

      loadCustomers();
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast({
        title: 'Error',
        description: `Failed to delete customer: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Form reset functions
  const resetOrderForm = () => {
    setNewOrder({
      order_date: new Date(),
      customer_id: 0,
      product_type: 'eggs',
      quantity: 0,
      unit_price: 0,
      total_amount: 0,
      payment_status: 'unpaid',
      delivery_date: new Date(new Date().setDate(new Date().getDate() + 1)),
      delivery_status: 'pending',
      notes: ''
    });
  };

  const resetCustomerForm = () => {
    setNewCustomer({
      customer_name: '',
      contact_person: '',
      phone: '',
      email: '',
      address: '',
      customer_type: 'consumer',
      notes: ''
    });
  };

  // Edit functions
  const editOrder = (order: any) => {
    setEditingOrder(order);
    setNewOrder({
      order_date: new Date(order.order_date),
      customer_id: order.customer_id,
      product_type: order.product_type,
      quantity: order.quantity,
      unit_price: order.unit_price,
      total_amount: order.total_amount,
      payment_status: order.payment_status,
      delivery_date: new Date(order.delivery_date),
      delivery_status: order.delivery_status,
      notes: order.notes || ''
    });
    setOrderDialog(true);
  };

  const editCustomer = (customer: any) => {
    setEditingCustomer(customer);
    setNewCustomer({
      customer_name: customer.customer_name,
      contact_person: customer.contact_person || '',
      phone: customer.phone || '',
      email: customer.email || '',
      address: customer.address || '',
      customer_type: customer.customer_type,
      notes: customer.notes || ''
    });
    setCustomerDialog(true);
  };

  // Handle form input changes
  const handleOrderInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewOrder((prev) => {
      const updatedOrder = {
        ...prev,
        [name]: name === 'quantity' || name === 'unit_price' ?
        parseFloat(value) || 0 :
        value
      };

      // Auto-calculate total amount when quantity or unit price changes
      if (name === 'quantity' || name === 'unit_price') {
        updatedOrder.total_amount = updatedOrder.quantity * updatedOrder.unit_price;
      }

      return updatedOrder;
    });
  };

  const handleCustomerInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewCustomer((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle date changes
  const handleOrderDateChange = (date: Date | undefined, dateField: string) => {
    if (!date) return;
    setNewOrder((prev) => ({
      ...prev,
      [dateField]: date
    }));
  };

  // Find customer name by ID
  const getCustomerNameById = (id: number) => {
    const customer = customers.find((c) => c.ID === id);
    return customer ? customer.customer_name : 'Unknown Customer';
  };

  // Load data on initial render and when page changes
  useEffect(() => {
    loadOrders();
  }, [ordersPage]);

  useEffect(() => {
    loadCustomers();
  }, [customersPage]);

  // Get badge color for payment status
  const getPaymentStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':return 'bg-green-100 text-green-800';
      case 'partial':return 'bg-yellow-100 text-yellow-800';
      case 'unpaid':return 'bg-red-100 text-red-800';
      default:return 'bg-gray-100';
    }
  };

  // Get badge color for delivery status
  const getDeliveryStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':return 'bg-green-100 text-green-800';
      case 'pending':return 'bg-blue-100 text-blue-800';
      case 'cancelled':return 'bg-red-100 text-red-800';
      default:return 'bg-gray-100';
    }
  };

  // Update delivery status
  const updateDeliveryStatus = async (orderId: number, status: string) => {
    try {
      const orderToUpdate = orders.find((o) => o.ID === orderId);
      if (!orderToUpdate) return;

      const response = await window.ezsite.apis.tableUpdate(5010, {
        ...orderToUpdate,
        delivery_status: status
      });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: `Order status updated to ${status}`
      });

      loadOrders();
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        title: 'Error',
        description: `Failed to update order status: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Update payment status
  const updatePaymentStatus = async (orderId: number, status: string) => {
    try {
      const orderToUpdate = orders.find((o) => o.ID === orderId);
      if (!orderToUpdate) return;

      const response = await window.ezsite.apis.tableUpdate(5010, {
        ...orderToUpdate,
        payment_status: status
      });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: `Payment status updated to ${status}`
      });

      loadOrders();
    } catch (error) {
      console.error('Error updating payment status:', error);
      toast({
        title: 'Error',
        description: `Failed to update payment status: ${error}`,
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-6" data-id="zapdniujh" data-path="src/pages/SalesPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="ilcvy8dpj" data-path="src/pages/SalesPage.tsx">
        <div data-id="87wbkqzl8" data-path="src/pages/SalesPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="1pwcm9fcf" data-path="src/pages/SalesPage.tsx">Sales & Orders</h1>
          <p className="text-muted-foreground" data-id="zwzzkkm5c" data-path="src/pages/SalesPage.tsx">
            Manage customer orders, sales, and deliveries
          </p>
        </div>
        <div className="flex gap-2" data-id="bd6e18718" data-path="src/pages/SalesPage.tsx">
          <Button variant="outline" onClick={() => {
            resetCustomerForm();
            setEditingCustomer(null);
            setCustomerDialog(true);
          }}>
            <Users size={16} className="mr-2" />
            Add Customer
          </Button>
          <Button onClick={() => {
            resetOrderForm();
            setEditingOrder(null);
            setOrderDialog(true);
          }}>
            <Plus size={16} className="mr-2" />
            Create Order
          </Button>
        </div>
      </div>

      <Tabs defaultValue="orders">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="customers">Customers</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="analytics">Sales Analytics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="orders" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="ytujnkl76" data-path="src/pages/SalesPage.tsx">
                <CardTitle>Active Orders</CardTitle>
                <CardDescription>
                  View and manage all current orders
                </CardDescription>
              </div>
              <div className="flex items-center gap-2" data-id="8anvhjta1" data-path="src/pages/SalesPage.tsx">
                <div className="relative w-full sm:w-64" data-id="wer4wshfm" data-path="src/pages/SalesPage.tsx">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search orders..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" onClick={loadOrders}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loadingOrders ?
              <div className="h-96 flex items-center justify-center" data-id="4ehrfdp5g" data-path="src/pages/SalesPage.tsx">
                  <p data-id="umsflrxjc" data-path="src/pages/SalesPage.tsx">Loading orders...</p>
                </div> :
              orders.length === 0 ?
              <div className="h-64 flex items-center justify-center border rounded-md" data-id="ngh9h3k87" data-path="src/pages/SalesPage.tsx">
                  <p className="text-muted-foreground" data-id="0u3rwfw68" data-path="src/pages/SalesPage.tsx">No orders found</p>
                </div> :

              <div className="rounded-md border" data-id="een6p9jv6" data-path="src/pages/SalesPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order Date</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Product</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead className="hidden md:table-cell">Payment</TableHead>
                        <TableHead className="hidden md:table-cell">Delivery</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) =>
                    <TableRow key={order.ID}>
                          <TableCell>{new Date(order.order_date).toLocaleDateString()}</TableCell>
                          <TableCell>{getCustomerNameById(order.customer_id)}</TableCell>
                          <TableCell>
                            {order.product_type.charAt(0).toUpperCase() + order.product_type.slice(1)} ({order.quantity})
                          </TableCell>
                          <TableCell className="font-medium">${order.total_amount.toFixed(2)}</TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Badge variant="outline" className={getPaymentStatusBadge(order.payment_status)}>
                              {order.payment_status}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">
                            <Badge variant="outline" className={getDeliveryStatusBadge(order.delivery_status)}>
                              {order.delivery_status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1" data-id="3y8fublgn" data-path="src/pages/SalesPage.tsx">
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => updatePaymentStatus(order.ID, 'paid')}>
                                <FileText className="h-4 w-4 text-green-500" />
                                <span className="sr-only" data-id="qmghk6xve" data-path="src/pages/SalesPage.tsx">Mark Paid</span>
                              </Button>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => updateDeliveryStatus(order.ID, 'completed')}>
                                <PackageCheck className="h-4 w-4 text-blue-500" />
                                <span className="sr-only" data-id="ysnrbdjso" data-path="src/pages/SalesPage.tsx">Complete Delivery</span>
                              </Button>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => editOrder(order)}>
                                <Edit className="h-4 w-4" />
                                <span className="sr-only" data-id="svfo2sv4y" data-path="src/pages/SalesPage.tsx">Edit</span>
                              </Button>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => deleteOrder(order.ID)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                                <span className="sr-only" data-id="exlfvq5o4" data-path="src/pages/SalesPage.tsx">Delete</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                    )}
                    </TableBody>
                  </Table>
                  <div className="flex items-center justify-center py-4" data-id="rb8bw9rj3" data-path="src/pages/SalesPage.tsx">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                          onClick={() => setOrdersPage((p) => Math.max(1, p - 1))}
                          className={ordersPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                        {[...Array(Math.min(5, Math.ceil(totalOrders / pageSize)))].map((_, i) => {
                        const pageNumber = i + 1;
                        const isCurrentPage = pageNumber === ordersPage;
                        return (
                          <PaginationItem key={i}>
                              <PaginationLink
                              isActive={isCurrentPage}
                              onClick={() => setOrdersPage(pageNumber)}
                              className="cursor-pointer">

                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>);

                      })}
                        {Math.ceil(totalOrders / pageSize) > 5 &&
                      <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                      }
                        <PaginationItem>
                          <PaginationNext
                          onClick={() => setOrdersPage((p) => Math.min(Math.ceil(totalOrders / pageSize), p + 1))}
                          className={ordersPage >= Math.ceil(totalOrders / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="customers" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="yefzjhhva" data-path="src/pages/SalesPage.tsx">
                <CardTitle>Customer Management</CardTitle>
                <CardDescription>
                  Manage customer information and history
                </CardDescription>
              </div>
              <div className="flex items-center gap-2" data-id="caijpou79" data-path="src/pages/SalesPage.tsx">
                <div className="relative w-full sm:w-64" data-id="lfw04zqwx" data-path="src/pages/SalesPage.tsx">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search customers..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" onClick={loadCustomers}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loadingCustomers ?
              <div className="h-96 flex items-center justify-center" data-id="yb0oicop0" data-path="src/pages/SalesPage.tsx">
                  <p data-id="clbdnwo7q" data-path="src/pages/SalesPage.tsx">Loading customers...</p>
                </div> :
              customers.length === 0 ?
              <div className="h-64 flex items-center justify-center border rounded-md" data-id="5pjxrkwsw" data-path="src/pages/SalesPage.tsx">
                  <p className="text-muted-foreground" data-id="x0j6mtp63" data-path="src/pages/SalesPage.tsx">No customers found</p>
                </div> :

              <div className="rounded-md border" data-id="2qlghfbqk" data-path="src/pages/SalesPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Customer Name</TableHead>
                        <TableHead>Contact Person</TableHead>
                        <TableHead className="hidden md:table-cell">Phone</TableHead>
                        <TableHead className="hidden md:table-cell">Email</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {customers.map((customer) =>
                    <TableRow key={customer.ID}>
                          <TableCell className="font-medium">{customer.customer_name}</TableCell>
                          <TableCell>{customer.contact_person}</TableCell>
                          <TableCell className="hidden md:table-cell">{customer.phone}</TableCell>
                          <TableCell className="hidden md:table-cell">{customer.email}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {customer.customer_type}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2" data-id="ns3f1higa" data-path="src/pages/SalesPage.tsx">
                              <Button variant="ghost" size="icon" onClick={() => editCustomer(customer)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => deleteCustomer(customer.ID)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                    )}
                    </TableBody>
                  </Table>
                  <div className="flex items-center justify-center py-4" data-id="c77lsj03w" data-path="src/pages/SalesPage.tsx">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                          onClick={() => setCustomersPage((p) => Math.max(1, p - 1))}
                          className={customersPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                        {[...Array(Math.min(5, Math.ceil(totalCustomers / pageSize)))].map((_, i) => {
                        const pageNumber = i + 1;
                        const isCurrentPage = pageNumber === customersPage;
                        return (
                          <PaginationItem key={i}>
                              <PaginationLink
                              isActive={isCurrentPage}
                              onClick={() => setCustomersPage(pageNumber)}
                              className="cursor-pointer">

                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>);

                      })}
                        {Math.ceil(totalCustomers / pageSize) > 5 &&
                      <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                      }
                        <PaginationItem>
                          <PaginationNext
                          onClick={() => setCustomersPage((p) => Math.min(Math.ceil(totalCustomers / pageSize), p + 1))}
                          className={customersPage >= Math.ceil(totalCustomers / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="invoices" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="ycuz5vckp" data-path="src/pages/SalesPage.tsx">
                <CardTitle>Invoices</CardTitle>
                <CardDescription>
                  Track invoices and payment status
                </CardDescription>
              </div>
              <div className="flex gap-2" data-id="6s9r67kh8" data-path="src/pages/SalesPage.tsx">
                <Button variant="outline">
                  <FileText size={16} className="mr-2" />
                  Generate Invoice
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4" data-id="a661ci4iv" data-path="src/pages/SalesPage.tsx">
                <div className="flex justify-between items-center" data-id="9ukl4wmsd" data-path="src/pages/SalesPage.tsx">
                  <div className="space-y-1" data-id="50uosjrwu" data-path="src/pages/SalesPage.tsx">
                    <h3 className="text-lg font-medium" data-id="m5r3own16" data-path="src/pages/SalesPage.tsx">Recent Invoices</h3>
                    <p className="text-sm text-muted-foreground" data-id="sbx7qr3kd" data-path="src/pages/SalesPage.tsx">View and manage generated invoices</p>
                  </div>
                  <div className="flex gap-2" data-id="e61f6ddey" data-path="src/pages/SalesPage.tsx">
                    <Select defaultValue="all">
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Invoices</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="unpaid">Unpaid</SelectItem>
                        <SelectItem value="overdue">Overdue</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="rounded-md border" data-id="cfw5w2347" data-path="src/pages/SalesPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Invoice #</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.slice(0, 5).map((order, index) =>
                      <TableRow key={`invoice-${order.ID}`}>
                          <TableCell className="font-medium">INV-{2023001 + index}</TableCell>
                          <TableCell>{getCustomerNameById(order.customer_id)}</TableCell>
                          <TableCell>{new Date(order.order_date).toLocaleDateString()}</TableCell>
                          <TableCell>${order.total_amount.toFixed(2)}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getPaymentStatusBadge(order.payment_status)}>
                              {order.payment_status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">View</Button>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Sales Analytics</CardTitle>
              <CardDescription>
                View sales trends and analytics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4" data-id="8kgxhzvqp" data-path="src/pages/SalesPage.tsx">
                <div className="border rounded-md p-4" data-id="cl2qbllpe" data-path="src/pages/SalesPage.tsx">
                  <h3 className="text-lg font-medium mb-2" data-id="12indnu9a" data-path="src/pages/SalesPage.tsx">Monthly Sales</h3>
                  <div className="h-64 flex items-center justify-center" data-id="irmj5ie4x" data-path="src/pages/SalesPage.tsx">
                    <p className="text-muted-foreground" data-id="m1ep65tpz" data-path="src/pages/SalesPage.tsx">Monthly sales chart will be displayed here</p>
                  </div>
                </div>
                <div className="border rounded-md p-4" data-id="8a5dua53v" data-path="src/pages/SalesPage.tsx">
                  <h3 className="text-lg font-medium mb-2" data-id="1kg9upltn" data-path="src/pages/SalesPage.tsx">Product Distribution</h3>
                  <div className="h-64 flex items-center justify-center" data-id="7telxz71t" data-path="src/pages/SalesPage.tsx">
                    <p className="text-muted-foreground" data-id="lnil64p8l" data-path="src/pages/SalesPage.tsx">Product distribution chart will be displayed here</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 border rounded-md p-4" data-id="j4ws13178" data-path="src/pages/SalesPage.tsx">
                <h3 className="text-lg font-medium mb-4" data-id="m6rah612h" data-path="src/pages/SalesPage.tsx">Sales Summary</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="omewuc8wu" data-path="src/pages/SalesPage.tsx">
                  <div className="bg-green-50 rounded-md p-4" data-id="8auoncnug" data-path="src/pages/SalesPage.tsx">
                    <p className="text-sm text-green-600 font-medium" data-id="otmwvrleo" data-path="src/pages/SalesPage.tsx">Total Sales (MTD)</p>
                    <p className="text-2xl font-bold mt-1" data-id="hriyemfp4" data-path="src/pages/SalesPage.tsx">$12,456.78</p>
                    <p className="text-xs text-green-600 mt-1" data-id="wtgp0d4fl" data-path="src/pages/SalesPage.tsx">↑ 12% from last month</p>
                  </div>
                  <div className="bg-blue-50 rounded-md p-4" data-id="dchppfqb5" data-path="src/pages/SalesPage.tsx">
                    <p className="text-sm text-blue-600 font-medium" data-id="br6djqi8f" data-path="src/pages/SalesPage.tsx">Average Order Value</p>
                    <p className="text-2xl font-bold mt-1" data-id="j97ekzbgb" data-path="src/pages/SalesPage.tsx">$245.32</p>
                    <p className="text-xs text-blue-600 mt-1" data-id="pg21ih6s2" data-path="src/pages/SalesPage.tsx">↑ 3% from last month</p>
                  </div>
                  <div className="bg-amber-50 rounded-md p-4" data-id="7xv6gmsuk" data-path="src/pages/SalesPage.tsx">
                    <p className="text-sm text-amber-600 font-medium" data-id="x5akjv5g2" data-path="src/pages/SalesPage.tsx">Active Customers</p>
                    <p className="text-2xl font-bold mt-1" data-id="pp7qowuko" data-path="src/pages/SalesPage.tsx">{customers.length}</p>
                    <p className="text-xs text-amber-600 mt-1" data-id="9wu90w14g" data-path="src/pages/SalesPage.tsx">↑ 5 new this month</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Order Dialog */}
      <Dialog open={orderDialog} onOpenChange={setOrderDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>{editingOrder ? 'Edit Order' : 'Create New Order'}</DialogTitle>
            <DialogDescription>
              {editingOrder ? 'Update order details' : 'Create a new customer order'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="xgbs807vz" data-path="src/pages/SalesPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="tqx6ov36c" data-path="src/pages/SalesPage.tsx">
              <div className="col-span-2" data-id="hbx6ghr5h" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="customer_id">Customer</Label>
                <Select
                  value={newOrder.customer_id.toString()}
                  onValueChange={(value) => setNewOrder((prev) => ({ ...prev, customer_id: parseInt(value) }))}>

                  <SelectTrigger>
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((customer) =>
                    <SelectItem key={customer.ID} value={customer.ID.toString()}>
                        {customer.customer_name}
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div data-id="u2cfzrif5" data-path="src/pages/SalesPage.tsx">
                <Label>Order Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newOrder.order_date ? format(newOrder.order_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newOrder.order_date} onSelect={(date) => handleOrderDateChange(date, 'order_date')} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="54a02lu2u" data-path="src/pages/SalesPage.tsx">
                <Label>Delivery Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newOrder.delivery_date ? format(newOrder.delivery_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newOrder.delivery_date} onSelect={(date) => handleOrderDateChange(date, 'delivery_date')} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="nmd29m0d3" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="product_type">Product Type</Label>
                <Select value={newOrder.product_type} onValueChange={(value) => setNewOrder((prev) => ({ ...prev, product_type: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select product" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="eggs">Eggs</SelectItem>
                    <SelectItem value="birds">Birds</SelectItem>
                    <SelectItem value="manure">Manure</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div data-id="jzjolc31i" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="quantity">Quantity</Label>
                <Input type="number" id="quantity" name="quantity" value={newOrder.quantity} onChange={handleOrderInputChange} className="mt-1" />
              </div>
              <div data-id="hgz9nxa33" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="unit_price">Unit Price</Label>
                <Input type="number" id="unit_price" name="unit_price" value={newOrder.unit_price} onChange={handleOrderInputChange} className="mt-1" step="0.01" />
              </div>
              <div data-id="jznxunys7" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="total_amount">Total Amount</Label>
                <Input type="number" id="total_amount" name="total_amount" value={newOrder.total_amount} disabled className="mt-1 bg-muted" />
              </div>
              <div className="col-span-2" data-id="8a01jxjsp" data-path="src/pages/SalesPage.tsx">
                <div className="flex justify-between mb-2" data-id="46byvl8h4" data-path="src/pages/SalesPage.tsx">
                  <Label>Payment Status</Label>
                  <div className="flex gap-2" data-id="hoch8j2d4" data-path="src/pages/SalesPage.tsx">
                    <Button
                      type="button"
                      variant={newOrder.payment_status === 'unpaid' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setNewOrder((prev) => ({ ...prev, payment_status: 'unpaid' }))}>

                      Unpaid
                    </Button>
                    <Button
                      type="button"
                      variant={newOrder.payment_status === 'partial' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setNewOrder((prev) => ({ ...prev, payment_status: 'partial' }))}>

                      Partial
                    </Button>
                    <Button
                      type="button"
                      variant={newOrder.payment_status === 'paid' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setNewOrder((prev) => ({ ...prev, payment_status: 'paid' }))}>

                      Paid
                    </Button>
                  </div>
                </div>
              </div>
              <div className="col-span-2" data-id="269u3n927" data-path="src/pages/SalesPage.tsx">
                <div className="flex justify-between mb-2" data-id="2kpqll0xq" data-path="src/pages/SalesPage.tsx">
                  <Label>Delivery Status</Label>
                  <div className="flex gap-2" data-id="p03n24y2f" data-path="src/pages/SalesPage.tsx">
                    <Button
                      type="button"
                      variant={newOrder.delivery_status === 'pending' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setNewOrder((prev) => ({ ...prev, delivery_status: 'pending' }))}>

                      Pending
                    </Button>
                    <Button
                      type="button"
                      variant={newOrder.delivery_status === 'completed' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setNewOrder((prev) => ({ ...prev, delivery_status: 'completed' }))}>

                      Completed
                    </Button>
                    <Button
                      type="button"
                      variant={newOrder.delivery_status === 'cancelled' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setNewOrder((prev) => ({ ...prev, delivery_status: 'cancelled' }))}>

                      Cancelled
                    </Button>
                  </div>
                </div>
              </div>
              <div className="col-span-2" data-id="addnyfr8d" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Input id="notes" name="notes" value={newOrder.notes} onChange={handleOrderInputChange} className="mt-1" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOrderDialog(false)}>Cancel</Button>
            <Button onClick={saveOrder}>{editingOrder ? 'Update Order' : 'Create Order'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Customer Dialog */}
      <Dialog open={customerDialog} onOpenChange={setCustomerDialog}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>{editingCustomer ? 'Edit Customer' : 'Add New Customer'}</DialogTitle>
            <DialogDescription>
              {editingCustomer ? 'Update customer information' : 'Add a new customer to your database'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="sgwed4tzo" data-path="src/pages/SalesPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="r5tpd7c5h" data-path="src/pages/SalesPage.tsx">
              <div className="col-span-2" data-id="oi8gptcer" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="customer_name">Customer Name</Label>
                <Input id="customer_name" name="customer_name" value={newCustomer.customer_name} onChange={handleCustomerInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="zc2ixq4q8" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="contact_person">Contact Person</Label>
                <Input id="contact_person" name="contact_person" value={newCustomer.contact_person} onChange={handleCustomerInputChange} className="mt-1" />
              </div>
              <div data-id="nn953lddp" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" name="phone" value={newCustomer.phone} onChange={handleCustomerInputChange} className="mt-1" />
              </div>
              <div data-id="3jstv96b5" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" value={newCustomer.email} onChange={handleCustomerInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="avfqrspoh" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="address">Address</Label>
                <Input id="address" name="address" value={newCustomer.address} onChange={handleCustomerInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="ntbrrz0ry" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="customer_type">Customer Type</Label>
                <Select value={newCustomer.customer_type} onValueChange={(value) => setNewCustomer((prev) => ({ ...prev, customer_type: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="consumer">Consumer</SelectItem>
                    <SelectItem value="retailer">Retailer</SelectItem>
                    <SelectItem value="wholesaler">Wholesaler</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2" data-id="llfjw4s8h" data-path="src/pages/SalesPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Input id="notes" name="notes" value={newCustomer.notes} onChange={handleCustomerInputChange} className="mt-1" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCustomerDialog(false)}>Cancel</Button>
            <Button onClick={saveCustomer}>{editingCustomer ? 'Update Customer' : 'Add Customer'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

};

export default SalesPage;