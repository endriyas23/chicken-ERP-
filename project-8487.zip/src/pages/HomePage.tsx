import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const HomePage: React.FC = () => {
  const { isAuthenticated, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading) {
      if (isAuthenticated) {
        navigate('/dashboard');
      } else {
        navigate('/login');
      }
    }
  }, [isAuthenticated, loading, navigate]);

  return (
    <div className="flex items-center justify-center h-screen" data-id="1crl1bis7" data-path="src/pages/HomePage.tsx">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary" data-id="5jo3pm6gg" data-path="src/pages/HomePage.tsx"></div>
    </div>);

};

export default HomePage;