import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { AlertCircle, BarChart3, Egg, TrendingUp, Users, Utensils, Zap } from 'lucide-react';

// Dashboard components
const DashboardPage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    totalBirds: 0,
    eggProduction: 0,
    mortalityRate: 0,
    feedStock: 0,
    revenue: 0
  });

  useEffect(() => {
    // Simulate fetching dashboard data
    const fetchDashboardData = async () => {
      try {
        // In a real application, this would be an API call
        setTimeout(() => {
          setDashboardData({
            totalBirds: 5250,
            eggProduction: 4200,
            mortalityRate: 0.5,
            feedStock: 1200,
            revenue: 25600
          });
          setIsLoading(false);
        }, 1000);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setIsLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full" data-id="28wdxdi54" data-path="src/pages/DashboardPage.tsx">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary" data-id="24qh3cyoa" data-path="src/pages/DashboardPage.tsx"></div>
      </div>);

  }

  return (
    <div className="space-y-6" data-id="cpyoot0s3" data-path="src/pages/DashboardPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="yv1vo7o3g" data-path="src/pages/DashboardPage.tsx">
        <div data-id="9dxpk3gjl" data-path="src/pages/DashboardPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="lh8p3rto7" data-path="src/pages/DashboardPage.tsx">Dashboard</h1>
          <p className="text-muted-foreground" data-id="7d3thyvzy" data-path="src/pages/DashboardPage.tsx">
            Overview of your farm's performance metrics
          </p>
        </div>
        <Button>
          <span className="hidden md:inline mr-2" data-id="5zxry4jiq" data-path="src/pages/DashboardPage.tsx">Generate Report</span>
          <BarChart3 size={16} />
        </Button>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="production">Production</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          {/* Key metrics */}
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5" data-id="b57ix7kad" data-path="src/pages/DashboardPage.tsx">
            <MetricCard
              title="Total Birds"
              value={dashboardData.totalBirds.toLocaleString()}
              description="Active birds in all flocks"
              icon={<Users className="h-6 w-6 text-blue-500" />}
              trend="+2.5%"
              trendDirection="up" />

            <MetricCard
              title="Egg Production"
              value={dashboardData.eggProduction.toLocaleString()}
              description="Today's collection"
              icon={<Egg className="h-6 w-6 text-yellow-500" />}
              trend="+5.2%"
              trendDirection="up" />

            <MetricCard
              title="Mortality Rate"
              value={`${dashboardData.mortalityRate}%`}
              description="Last 30 days average"
              icon={<AlertCircle className="h-6 w-6 text-red-500" />}
              trend="-0.3%"
              trendDirection="down"
              trendPositive={true} />

            <MetricCard
              title="Feed Stock"
              value={`${dashboardData.feedStock} kg`}
              description="Current inventory"
              icon={<Utensils className="h-6 w-6 text-green-500" />}
              trend="-120kg"
              trendDirection="down"
              trendPositive={false} />

            <MetricCard
              title="Revenue"
              value={`$${dashboardData.revenue.toLocaleString()}`}
              description="This month"
              icon={<Zap className="h-6 w-6 text-purple-500" />}
              trend="+12.3%"
              trendDirection="up" />

          </div>

          {/* Charts and Alerts */}
          <div className="grid gap-4 grid-cols-1 lg:grid-cols-2" data-id="1lva2p4vk" data-path="src/pages/DashboardPage.tsx">
            <Card>
              <CardHeader>
                <CardTitle>Egg Production Trend</CardTitle>
                <CardDescription>Daily egg collection (last 30 days)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80 w-full bg-muted rounded-md flex items-center justify-center" data-id="mw34yzpyd" data-path="src/pages/DashboardPage.tsx">
                  <p className="text-muted-foreground" data-id="kouqf3qwt" data-path="src/pages/DashboardPage.tsx">Production Chart</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Current Alerts</CardTitle>
                <CardDescription>Issues requiring attention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4" data-id="i2p8hirb1" data-path="src/pages/DashboardPage.tsx">
                  <Alert
                    title="Feed Stock Low"
                    description="Layer feed stock below reorder level"
                    type="warning" />

                  <Alert
                    title="Mortality Rate Increased"
                    description="Flock #B12 has 2.5% mortality in the last week"
                    type="error" />

                  <Alert
                    title="Vaccination Due"
                    description="Flock #A05 is due for Newcastle vaccination tomorrow"
                    type="info" />

                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="production" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Production Statistics</CardTitle>
              <CardDescription>Detailed egg production data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full bg-muted rounded-md flex items-center justify-center" data-id="kf042rptm" data-path="src/pages/DashboardPage.tsx">
                <p className="text-muted-foreground" data-id="qxxlwyj99" data-path="src/pages/DashboardPage.tsx">Production Statistics Chart</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Financial Overview</CardTitle>
              <CardDescription>Income vs. expenses breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 w-full bg-muted rounded-md flex items-center justify-center" data-id="wyvp1tjzf" data-path="src/pages/DashboardPage.tsx">
                <p className="text-muted-foreground" data-id="igra29nr0" data-path="src/pages/DashboardPage.tsx">Financial Chart</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

// MetricCard Component
interface MetricCardProps {
  title: string;
  value: string;
  description: string;
  icon: React.ReactNode;
  trend: string;
  trendDirection: 'up' | 'down';
  trendPositive?: boolean;
}

const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  description,
  icon,
  trend,
  trendDirection,
  trendPositive = trendDirection === 'up'
}) => {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-start" data-id="i4pp9u1mh" data-path="src/pages/DashboardPage.tsx">
          <div data-id="k82l5icw1" data-path="src/pages/DashboardPage.tsx">
            <p className="text-sm font-medium text-muted-foreground mb-1" data-id="nnm4rcyn2" data-path="src/pages/DashboardPage.tsx">{title}</p>
            <h3 className="text-2xl font-bold" data-id="aagbdzjy2" data-path="src/pages/DashboardPage.tsx">{value}</h3>
            <p className="text-xs text-muted-foreground mt-1" data-id="2xsl18dte" data-path="src/pages/DashboardPage.tsx">{description}</p>
          </div>
          <div className="bg-primary/10 p-2 rounded-full" data-id="yncy19fqq" data-path="src/pages/DashboardPage.tsx">{icon}</div>
        </div>
        <div className="mt-3" data-id="qnr062490" data-path="src/pages/DashboardPage.tsx">
          <span
            className={`text-xs font-medium flex items-center gap-1 ${
            trendPositive ? 'text-green-600' : 'text-red-600'}`
            } data-id="oc9lfzj35" data-path="src/pages/DashboardPage.tsx">

            {trend}
            {trendDirection === 'up' ?
            <TrendingUp size={14} /> :

            <TrendingUp size={14} className="rotate-180" />
            }
          </span>
        </div>
      </CardContent>
    </Card>);

};

// Alert Component
interface AlertProps {
  title: string;
  description: string;
  type: 'info' | 'warning' | 'error' | 'success';
}

const Alert: React.FC<AlertProps> = ({ title, description, type }) => {
  const bgColor = {
    info: 'bg-blue-50',
    warning: 'bg-yellow-50',
    error: 'bg-red-50',
    success: 'bg-green-50'
  }[type];

  const textColor = {
    info: 'text-blue-800',
    warning: 'text-yellow-800',
    error: 'text-red-800',
    success: 'text-green-800'
  }[type];

  const borderColor = {
    info: 'border-blue-200',
    warning: 'border-yellow-200',
    error: 'border-red-200',
    success: 'border-green-200'
  }[type];

  return (
    <div className={`p-3 rounded-md ${bgColor} ${borderColor} border`} data-id="pk6ne0g05" data-path="src/pages/DashboardPage.tsx">
      <div className="flex items-start" data-id="a97zkbz8d" data-path="src/pages/DashboardPage.tsx">
        <div className="flex-shrink-0" data-id="ysh26ne7z" data-path="src/pages/DashboardPage.tsx">
          <AlertCircle className={`h-5 w-5 ${textColor}`} />
        </div>
        <div className="ml-3" data-id="kuji4en8k" data-path="src/pages/DashboardPage.tsx">
          <h3 className={`text-sm font-medium ${textColor}`} data-id="7u019wapq" data-path="src/pages/DashboardPage.tsx">{title}</h3>
          <div className={`mt-1 text-sm ${textColor} opacity-80`} data-id="124arsyam" data-path="src/pages/DashboardPage.tsx">{description}</div>
        </div>
      </div>
    </div>);

};

export default DashboardPage;