import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Egg } from 'lucide-react';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Get the redirect path from location state, or default to dashboard
  const from = (location.state as any)?.from?.pathname || '/dashboard';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);

    try {
      await login(email, password);
      navigate(from, { replace: true });
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200 p-4" data-id="wbzy7id59" data-path="src/pages/LoginPage.tsx">
      <div className="w-full max-w-md" data-id="85q9qwj41" data-path="src/pages/LoginPage.tsx">
        <Card className="shadow-lg">
          <CardHeader className="space-y-1 flex flex-col items-center">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2" data-id="8mw3ez1ev" data-path="src/pages/LoginPage.tsx">
              <Egg size={24} className="text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold text-center">Chicken Farm ERP</CardTitle>
            <CardDescription className="text-center">
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleSubmit} data-id="x9f738ys3" data-path="src/pages/LoginPage.tsx">
            <CardContent className="space-y-4">
              {errorMessage &&
              <Alert variant="destructive">
                  <AlertDescription>{errorMessage}</AlertDescription>
                </Alert>
              }
              <div className="space-y-2" data-id="lj6oyuvwz" data-path="src/pages/LoginPage.tsx">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required />

              </div>
              <div className="space-y-2" data-id="9kxn8mga8" data-path="src/pages/LoginPage.tsx">
                <div className="flex items-center justify-between" data-id="dnsh7mms0" data-path="src/pages/LoginPage.tsx">
                  <Label htmlFor="password">Password</Label>
                </div>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required />

              </div>
            </CardContent>
            <CardFooter>
              <Button
                type="submit"
                className="w-full"
                disabled={isLoading}>

                {isLoading ?
                <span className="flex items-center gap-2" data-id="ya8v3mbfv" data-path="src/pages/LoginPage.tsx">
                    <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" data-id="mtgnlcwxv" data-path="src/pages/LoginPage.tsx"></div>
                    Signing in...
                  </span> :

                'Sign In'
                }
              </Button>
            </CardFooter>
          </form>
        </Card>
      </div>
    </div>);

};

export default LoginPage;