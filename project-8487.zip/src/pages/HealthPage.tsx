import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Plus, PlusCircle, Trash2, Edit, Search, RotateCcw, AlertCircle, FileX, Calendar as CalendarIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const HealthPage: React.FC = () => {
  const { toast } = useToast();
  const [healthRecords, setHealthRecords] = useState<any[]>([]);
  const [mortalityRecords, setMortalityRecords] = useState<any[]>([]);
  const [loadingHealth, setLoadingHealth] = useState(false);
  const [loadingMortality, setLoadingMortality] = useState(false);
  const [healthDialog, setHealthDialog] = useState(false);
  const [mortalityDialog, setMortalityDialog] = useState(false);
  const [healthPage, setHealthPage] = useState(1);
  const [mortalityPage, setMortalityPage] = useState(1);
  const [totalHealthItems, setTotalHealthItems] = useState(0);
  const [totalMortalityItems, setTotalMortalityItems] = useState(0);
  const [flocksList, setFlocksList] = useState<any[]>([]);
  const [editingHealth, setEditingHealth] = useState<any>(null);
  const [editingMortality, setEditingMortality] = useState<any>(null);
  const pageSize = 10;

  // Form state for health record
  const [newHealth, setNewHealth] = useState({
    flock_id: '',
    record_date: new Date(),
    record_type: 'check',
    symptoms: '',
    diagnosis: '',
    treatment: '',
    medication: '',
    dosage: '',
    conducted_by: '',
    notes: '',
    image: 0
  });

  // Form state for mortality record
  const [newMortality, setNewMortality] = useState({
    flock_id: '',
    date: new Date(),
    count: 0,
    cause: '',
    age_weeks: 0,
    shed_location: '',
    reported_by: '',
    notes: '',
    image: 0
  });

  // Mock function for file upload (to be implemented with real API)
  const [selectedHealthFile, setSelectedHealthFile] = useState<File | null>(null);
  const [selectedMortalityFile, setSelectedMortalityFile] = useState<File | null>(null);
  const [vaccinationView, setVaccinationView] = useState('upcoming');

  // Load health records
  const loadHealthRecords = async () => {
    setLoadingHealth(true);
    try {
      const response = await window.ezsite.apis.tablePage(5006, {
        PageNo: healthPage,
        PageSize: pageSize,
        OrderByField: "record_date",
        IsAsc: false
      });

      if (response.error) throw response.error;

      setHealthRecords(response.data.List);
      setTotalHealthItems(response.data.VirtualCount);
    } catch (error) {
      console.error('Error loading health records:', error);
      toast({
        title: 'Error',
        description: `Failed to load health records: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setLoadingHealth(false);
    }
  };

  // Load mortality records
  const loadMortalityRecords = async () => {
    setLoadingMortality(true);
    try {
      const response = await window.ezsite.apis.tablePage(5007, {
        PageNo: mortalityPage,
        PageSize: pageSize,
        OrderByField: "date",
        IsAsc: false
      });

      if (response.error) throw response.error;

      setMortalityRecords(response.data.List);
      setTotalMortalityItems(response.data.VirtualCount);
    } catch (error) {
      console.error('Error loading mortality records:', error);
      toast({
        title: 'Error',
        description: `Failed to load mortality records: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setLoadingMortality(false);
    }
  };

  // Load flocks for dropdown
  const loadFlocks = async () => {
    try {
      const response = await window.ezsite.apis.tablePage(5003, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: "arrival_date",
        IsAsc: false,
        Filters: [
        {
          name: "status",
          op: "Equal",
          value: "active"
        }]

      });

      if (response.error) throw response.error;
      setFlocksList(response.data.List);
    } catch (error) {
      console.error('Error loading flocks:', error);
      toast({
        title: 'Error',
        description: `Failed to load flocks: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Handle file upload
  const handleFileUpload = async (file: File) => {
    if (!file) return 0;

    try {
      const response = await window.ezsite.apis.upload({
        filename: file.name,
        file: file
      });

      if (response.error) throw response.error;
      return response.data;
    } catch (error) {
      console.error('Error uploading file:', error);
      toast({
        title: 'Error',
        description: `Failed to upload file: ${error}`,
        variant: 'destructive'
      });
      return 0;
    }
  };

  // Add or update health record
  const saveHealthRecord = async () => {
    try {
      let imageId = newHealth.image;

      if (selectedHealthFile) {
        imageId = await handleFileUpload(selectedHealthFile);
      }

      let response;
      if (editingHealth) {
        response = await window.ezsite.apis.tableUpdate(5006, {
          ...newHealth,
          image: imageId,
          ID: editingHealth.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5006, {
          ...newHealth,
          image: imageId
        });
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingHealth ? 'Health record updated successfully' : 'New health record added'
      });

      setHealthDialog(false);
      setEditingHealth(null);
      setSelectedHealthFile(null);
      resetHealthForm();
      loadHealthRecords();
    } catch (error) {
      console.error('Error saving health record:', error);
      toast({
        title: 'Error',
        description: `Failed to save health record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Add or update mortality record
  const saveMortalityRecord = async () => {
    try {
      let imageId = newMortality.image;

      if (selectedMortalityFile) {
        imageId = await handleFileUpload(selectedMortalityFile);
      }

      let response;
      if (editingMortality) {
        response = await window.ezsite.apis.tableUpdate(5007, {
          ...newMortality,
          image: imageId,
          ID: editingMortality.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5007, {
          ...newMortality,
          image: imageId
        });
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingMortality ? 'Mortality record updated successfully' : 'New mortality record added'
      });

      setMortalityDialog(false);
      setEditingMortality(null);
      setSelectedMortalityFile(null);
      resetMortalityForm();
      loadMortalityRecords();
    } catch (error) {
      console.error('Error saving mortality record:', error);
      toast({
        title: 'Error',
        description: `Failed to save mortality record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete health record
  const deleteHealthRecord = async (id: number) => {
    if (!confirm('Are you sure you want to delete this health record?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5006, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Health record deleted successfully'
      });

      loadHealthRecords();
    } catch (error) {
      console.error('Error deleting health record:', error);
      toast({
        title: 'Error',
        description: `Failed to delete health record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete mortality record
  const deleteMortalityRecord = async (id: number) => {
    if (!confirm('Are you sure you want to delete this mortality record?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5007, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Mortality record deleted successfully'
      });

      loadMortalityRecords();
    } catch (error) {
      console.error('Error deleting mortality record:', error);
      toast({
        title: 'Error',
        description: `Failed to delete mortality record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Form reset functions
  const resetHealthForm = () => {
    setNewHealth({
      flock_id: '',
      record_date: new Date(),
      record_type: 'check',
      symptoms: '',
      diagnosis: '',
      treatment: '',
      medication: '',
      dosage: '',
      conducted_by: '',
      notes: '',
      image: 0
    });
  };

  const resetMortalityForm = () => {
    setNewMortality({
      flock_id: '',
      date: new Date(),
      count: 0,
      cause: '',
      age_weeks: 0,
      shed_location: '',
      reported_by: '',
      notes: '',
      image: 0
    });
  };

  // Edit functions
  const editHealth = (record: any) => {
    setEditingHealth(record);
    setNewHealth({
      flock_id: record.flock_id,
      record_date: new Date(record.record_date),
      record_type: record.record_type,
      symptoms: record.symptoms || '',
      diagnosis: record.diagnosis || '',
      treatment: record.treatment || '',
      medication: record.medication || '',
      dosage: record.dosage || '',
      conducted_by: record.conducted_by || '',
      notes: record.notes || '',
      image: record.image || 0
    });
    setHealthDialog(true);
  };

  const editMortality = (record: any) => {
    setEditingMortality(record);
    setNewMortality({
      flock_id: record.flock_id,
      date: new Date(record.date),
      count: record.count,
      cause: record.cause || '',
      age_weeks: record.age_weeks,
      shed_location: record.shed_location || '',
      reported_by: record.reported_by || '',
      notes: record.notes || '',
      image: record.image || 0
    });
    setMortalityDialog(true);
  };

  // Handle form input changes
  const handleHealthInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewHealth((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleMortalityInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewMortality((prev) => ({
      ...prev,
      [name]: name === 'count' || name === 'age_weeks' ? parseInt(value) || 0 : value
    }));
  };

  // Handle date changes
  const handleHealthDateChange = (date: Date | undefined) => {
    if (!date) return;
    setNewHealth((prev) => ({
      ...prev,
      record_date: date
    }));
  };

  const handleMortalityDateChange = (date: Date | undefined) => {
    if (!date) return;
    setNewMortality((prev) => ({
      ...prev,
      date: date
    }));
  };

  // Load data on initial render and when page changes
  useEffect(() => {
    loadHealthRecords();
  }, [healthPage]);

  useEffect(() => {
    loadMortalityRecords();
  }, [mortalityPage]);

  useEffect(() => {
    loadFlocks();
  }, []);

  // Get record type badge color
  const getRecordTypeBadge = (type: string) => {
    switch (type) {
      case 'check':return 'bg-blue-100 text-blue-800';
      case 'treatment':return 'bg-green-100 text-green-800';
      case 'vaccination':return 'bg-purple-100 text-purple-800';
      default:return 'bg-gray-100';
    }
  };

  return (
    <div className="space-y-6" data-id="bwmet4aaq" data-path="src/pages/HealthPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="9zpajyzkf" data-path="src/pages/HealthPage.tsx">
        <div data-id="04i06y6us" data-path="src/pages/HealthPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="5bguy92b7" data-path="src/pages/HealthPage.tsx">Health & Mortality</h1>
          <p className="text-muted-foreground" data-id="146eyg3l7" data-path="src/pages/HealthPage.tsx">
            Track health records, vaccinations, and mortality data
          </p>
        </div>
        <div className="flex gap-2" data-id="tgmkxth8a" data-path="src/pages/HealthPage.tsx">
          <Button onClick={() => {
            resetHealthForm();
            setEditingHealth(null);
            setHealthDialog(true);
          }}>
            <Plus size={16} className="mr-2" />
            Add Health Record
          </Button>
          <Button variant="outline" onClick={() => {
            resetMortalityForm();
            setEditingMortality(null);
            setMortalityDialog(true);
          }}>
            <FileX size={16} className="mr-2" />
            Record Mortality
          </Button>
        </div>
      </div>

      <Tabs defaultValue="health">
        <TabsList>
          <TabsTrigger value="health">Health Records</TabsTrigger>
          <TabsTrigger value="vaccinations">Vaccinations</TabsTrigger>
          <TabsTrigger value="mortality">Mortality</TabsTrigger>
        </TabsList>
        
        <TabsContent value="health" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="jyfdtf03c" data-path="src/pages/HealthPage.tsx">
                <CardTitle>Health Records</CardTitle>
                <CardDescription>
                  Track health checks, treatments, and issues
                </CardDescription>
              </div>
              <div className="flex items-center gap-2" data-id="xjzfhg0cs" data-path="src/pages/HealthPage.tsx">
                <div className="relative w-full sm:w-64" data-id="o4hr9apjm" data-path="src/pages/HealthPage.tsx">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search records..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" onClick={loadHealthRecords}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loadingHealth ?
              <div className="h-96 flex items-center justify-center" data-id="cbipipof6" data-path="src/pages/HealthPage.tsx">
                  <p data-id="gtcek3m0l" data-path="src/pages/HealthPage.tsx">Loading health records...</p>
                </div> :
              healthRecords.length === 0 ?
              <div className="h-64 flex items-center justify-center border rounded-md" data-id="os48cgoh1" data-path="src/pages/HealthPage.tsx">
                  <p className="text-muted-foreground" data-id="lt55xsw0s" data-path="src/pages/HealthPage.tsx">No health records found</p>
                </div> :

              <div className="rounded-md border" data-id="epvyszbrx" data-path="src/pages/HealthPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Flock ID</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="hidden md:table-cell">Diagnosis</TableHead>
                        <TableHead className="hidden md:table-cell">Treatment</TableHead>
                        <TableHead>Conducted By</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {healthRecords.map((record) =>
                    <TableRow key={record.ID}>
                          <TableCell>{new Date(record.record_date).toLocaleDateString()}</TableCell>
                          <TableCell>{record.flock_id}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={getRecordTypeBadge(record.record_type)}>
                              {record.record_type.charAt(0).toUpperCase() + record.record_type.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden md:table-cell">{record.diagnosis || '—'}</TableCell>
                          <TableCell className="hidden md:table-cell">{record.treatment || '—'}</TableCell>
                          <TableCell>{record.conducted_by}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2" data-id="iibtofrjh" data-path="src/pages/HealthPage.tsx">
                              <Button variant="ghost" size="icon" onClick={() => editHealth(record)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => deleteHealthRecord(record.ID)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                    )}
                    </TableBody>
                  </Table>
                  <div className="flex items-center justify-center py-4" data-id="8ceyw0as3" data-path="src/pages/HealthPage.tsx">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                          onClick={() => setHealthPage((p) => Math.max(1, p - 1))}
                          className={healthPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                        {[...Array(Math.min(5, Math.ceil(totalHealthItems / pageSize)))].map((_, i) => {
                        const pageNumber = i + 1;
                        const isCurrentPage = pageNumber === healthPage;
                        return (
                          <PaginationItem key={i}>
                              <PaginationLink
                              isActive={isCurrentPage}
                              onClick={() => setHealthPage(pageNumber)}
                              className="cursor-pointer">

                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>);

                      })}
                        {Math.ceil(totalHealthItems / pageSize) > 5 &&
                      <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                      }
                        <PaginationItem>
                          <PaginationNext
                          onClick={() => setHealthPage((p) => Math.min(Math.ceil(totalHealthItems / pageSize), p + 1))}
                          className={healthPage >= Math.ceil(totalHealthItems / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="vaccinations" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center">
              <div data-id="k9thmnlnr" data-path="src/pages/HealthPage.tsx">
                <CardTitle>Vaccination Schedule</CardTitle>
                <CardDescription>
                  Manage vaccination schedule and records
                </CardDescription>
              </div>
              <div className="flex gap-2" data-id="lxriv4kba" data-path="src/pages/HealthPage.tsx">
                <Button variant={vaccinationView === 'upcoming' ? 'default' : 'outline'} size="sm" onClick={() => setVaccinationView('upcoming')}>Upcoming</Button>
                <Button variant={vaccinationView === 'history' ? 'default' : 'outline'} size="sm" onClick={() => setVaccinationView('history')}>History</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border" data-id="wue5im3ji" data-path="src/pages/HealthPage.tsx">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Flock ID</TableHead>
                      <TableHead>Vaccine Type</TableHead>
                      <TableHead>Age (weeks)</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {vaccinationView === 'upcoming' ?
                    <>
                        <TableRow>
                          <TableCell>{new Date().toLocaleDateString()}</TableCell>
                          <TableCell>A123</TableCell>
                          <TableCell>Newcastle Disease</TableCell>
                          <TableCell>4</TableCell>
                          <TableCell><Badge>Scheduled</Badge></TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">Mark Complete</Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}</TableCell>
                          <TableCell>B456</TableCell>
                          <TableCell>Infectious Bronchitis</TableCell>
                          <TableCell>6</TableCell>
                          <TableCell><Badge variant="outline">Pending</Badge></TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm">Reschedule</Button>
                          </TableCell>
                        </TableRow>
                      </> :

                    <>
                        <TableRow>
                          <TableCell>{new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toLocaleDateString()}</TableCell>
                          <TableCell>A123</TableCell>
                          <TableCell>Marek's Disease</TableCell>
                          <TableCell>1</TableCell>
                          <TableCell><Badge variant="success">Completed</Badge></TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">View Details</Button>
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell>{new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toLocaleDateString()}</TableCell>
                          <TableCell>C789</TableCell>
                          <TableCell>Infectious Bursal Disease</TableCell>
                          <TableCell>3</TableCell>
                          <TableCell><Badge variant="success">Completed</Badge></TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">View Details</Button>
                          </TableCell>
                        </TableRow>
                      </>
                    }
                  </TableBody>
                </Table>
              </div>
              <div className="mt-4 flex justify-end" data-id="0nrjtrn2i" data-path="src/pages/HealthPage.tsx">
                <Button onClick={() => {
                  resetHealthForm();
                  setNewHealth((prev) => ({ ...prev, record_type: 'vaccination' }));
                  setEditingHealth(null);
                  setHealthDialog(true);
                }}>
                  <PlusCircle size={16} className="mr-2" />
                  Schedule Vaccination
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="mortality" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="srlk6v2z6" data-path="src/pages/HealthPage.tsx">
                <CardTitle>Mortality Records</CardTitle>
                <CardDescription>
                  Track bird mortality and causes
                </CardDescription>
              </div>
              <div className="flex items-center gap-2" data-id="xyx9mlthw" data-path="src/pages/HealthPage.tsx">
                <div className="relative w-full sm:w-64" data-id="8qjqdwrll" data-path="src/pages/HealthPage.tsx">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search records..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" onClick={loadMortalityRecords}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loadingMortality ?
              <div className="h-96 flex items-center justify-center" data-id="ze4mo56w1" data-path="src/pages/HealthPage.tsx">
                  <p data-id="v1kutf3zy" data-path="src/pages/HealthPage.tsx">Loading mortality records...</p>
                </div> :
              mortalityRecords.length === 0 ?
              <div className="h-64 flex items-center justify-center border rounded-md" data-id="gtemswtvy" data-path="src/pages/HealthPage.tsx">
                  <p className="text-muted-foreground" data-id="bcg91ianl" data-path="src/pages/HealthPage.tsx">No mortality records found</p>
                </div> :

              <div className="rounded-md border" data-id="6fmis5ums" data-path="src/pages/HealthPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Flock ID</TableHead>
                        <TableHead>Count</TableHead>
                        <TableHead>Cause</TableHead>
                        <TableHead className="hidden md:table-cell">Age (weeks)</TableHead>
                        <TableHead className="hidden md:table-cell">Location</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mortalityRecords.map((record) =>
                    <TableRow key={record.ID}>
                          <TableCell>{new Date(record.date).toLocaleDateString()}</TableCell>
                          <TableCell>{record.flock_id}</TableCell>
                          <TableCell>
                            <Badge variant="destructive">{record.count}</Badge>
                          </TableCell>
                          <TableCell>{record.cause || '—'}</TableCell>
                          <TableCell className="hidden md:table-cell">{record.age_weeks}</TableCell>
                          <TableCell className="hidden md:table-cell">{record.shed_location}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2" data-id="7sgfepu5l" data-path="src/pages/HealthPage.tsx">
                              <Button variant="ghost" size="icon" onClick={() => editMortality(record)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => deleteMortalityRecord(record.ID)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                    )}
                    </TableBody>
                  </Table>
                  <div className="flex items-center justify-center py-4" data-id="yqm9g7czg" data-path="src/pages/HealthPage.tsx">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                          onClick={() => setMortalityPage((p) => Math.max(1, p - 1))}
                          className={mortalityPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                        {[...Array(Math.min(5, Math.ceil(totalMortalityItems / pageSize)))].map((_, i) => {
                        const pageNumber = i + 1;
                        const isCurrentPage = pageNumber === mortalityPage;
                        return (
                          <PaginationItem key={i}>
                              <PaginationLink
                              isActive={isCurrentPage}
                              onClick={() => setMortalityPage(pageNumber)}
                              className="cursor-pointer">

                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>);

                      })}
                        {Math.ceil(totalMortalityItems / pageSize) > 5 &&
                      <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                      }
                        <PaginationItem>
                          <PaginationNext
                          onClick={() => setMortalityPage((p) => Math.min(Math.ceil(totalMortalityItems / pageSize), p + 1))}
                          className={mortalityPage >= Math.ceil(totalMortalityItems / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Health Record Dialog */}
      <Dialog open={healthDialog} onOpenChange={setHealthDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{editingHealth ? 'Edit Health Record' : 'Add New Health Record'}</DialogTitle>
            <DialogDescription>
              {editingHealth ? 'Update health record details' : 'Add a new health record for a flock'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="hkpueq54c" data-path="src/pages/HealthPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="szdl6t1ym" data-path="src/pages/HealthPage.tsx">
              <div data-id="kx7gm42z2" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="flock_id">Flock</Label>
                <Select value={newHealth.flock_id} onValueChange={(value) => setNewHealth((prev) => ({ ...prev, flock_id: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select flock" />
                  </SelectTrigger>
                  <SelectContent>
                    {flocksList.map((flock) =>
                    <SelectItem key={flock.ID} value={flock.flock_id}>{flock.flock_id} - {flock.breed}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div data-id="i6git9e4p" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="record_type">Record Type</Label>
                <Select value={newHealth.record_type} onValueChange={(value) => setNewHealth((prev) => ({ ...prev, record_type: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="check">Health Check</SelectItem>
                    <SelectItem value="treatment">Treatment</SelectItem>
                    <SelectItem value="vaccination">Vaccination</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div data-id="offpn2xx8" data-path="src/pages/HealthPage.tsx">
                <Label>Record Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newHealth.record_date ? format(newHealth.record_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newHealth.record_date} onSelect={handleHealthDateChange} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="ri9noumvp" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="conducted_by">Conducted By</Label>
                <Input id="conducted_by" name="conducted_by" value={newHealth.conducted_by} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="nhuajptl0" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="symptoms">Symptoms</Label>
                <Textarea id="symptoms" name="symptoms" value={newHealth.symptoms} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="bhul6dvhu" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="diagnosis">Diagnosis</Label>
                <Input id="diagnosis" name="diagnosis" value={newHealth.diagnosis} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="ko9ge0hgi" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="treatment">Treatment</Label>
                <Textarea id="treatment" name="treatment" value={newHealth.treatment} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div data-id="iapmiap14" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="medication">Medication</Label>
                <Input id="medication" name="medication" value={newHealth.medication} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div data-id="jofluwkc7" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="dosage">Dosage</Label>
                <Input id="dosage" name="dosage" value={newHealth.dosage} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="weibi87pz" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Textarea id="notes" name="notes" value={newHealth.notes} onChange={handleHealthInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="ihddkun1d" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="image">Photo Documentation</Label>
                <Input
                  id="image"
                  type="file"
                  className="mt-1"
                  accept="image/*"
                  onChange={(e) => e.target.files && setSelectedHealthFile(e.target.files[0])} />

                {editingHealth && editingHealth.image > 0 &&
                <p className="text-sm text-muted-foreground mt-1" data-id="jjuxfq62t" data-path="src/pages/HealthPage.tsx">Image already uploaded. Upload new image to replace.</p>
                }
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setHealthDialog(false)}>Cancel</Button>
            <Button onClick={saveHealthRecord}>{editingHealth ? 'Update Record' : 'Save Record'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Mortality Record Dialog */}
      <Dialog open={mortalityDialog} onOpenChange={setMortalityDialog}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>{editingMortality ? 'Edit Mortality Record' : 'Record Bird Mortality'}</DialogTitle>
            <DialogDescription>
              {editingMortality ? 'Update mortality record details' : 'Record bird deaths and track mortality causes'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="jd7i8baop" data-path="src/pages/HealthPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="mrfbazbom" data-path="src/pages/HealthPage.tsx">
              <div data-id="w72vf3w7j" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="flock_id">Flock</Label>
                <Select value={newMortality.flock_id} onValueChange={(value) => setNewMortality((prev) => ({ ...prev, flock_id: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select flock" />
                  </SelectTrigger>
                  <SelectContent>
                    {flocksList.map((flock) =>
                    <SelectItem key={flock.ID} value={flock.flock_id}>{flock.flock_id} - {flock.breed}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div data-id="b2zlvnkl0" data-path="src/pages/HealthPage.tsx">
                <Label>Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newMortality.date ? format(newMortality.date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newMortality.date} onSelect={handleMortalityDateChange} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="pd6s7r66c" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="count">Number of Deaths</Label>
                <Input type="number" id="count" name="count" value={newMortality.count} onChange={handleMortalityInputChange} className="mt-1" />
              </div>
              <div data-id="0apw29eko" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="age_weeks">Age (weeks)</Label>
                <Input type="number" id="age_weeks" name="age_weeks" value={newMortality.age_weeks} onChange={handleMortalityInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="anfsa4ehi" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="cause">Cause of Death</Label>
                <Input id="cause" name="cause" value={newMortality.cause} onChange={handleMortalityInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="a0etmvl30" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="shed_location">Shed/Location</Label>
                <Input id="shed_location" name="shed_location" value={newMortality.shed_location} onChange={handleMortalityInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="olaulhp8c" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="reported_by">Reported By</Label>
                <Input id="reported_by" name="reported_by" value={newMortality.reported_by} onChange={handleMortalityInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="s1kacdv7y" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Textarea id="notes" name="notes" value={newMortality.notes} onChange={handleMortalityInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="f34i3qdjx" data-path="src/pages/HealthPage.tsx">
                <Label htmlFor="mortality_image">Photo Documentation</Label>
                <Input
                  id="mortality_image"
                  type="file"
                  className="mt-1"
                  accept="image/*"
                  onChange={(e) => e.target.files && setSelectedMortalityFile(e.target.files[0])} />

                {editingMortality && editingMortality.image > 0 &&
                <p className="text-sm text-muted-foreground mt-1" data-id="r01aqjek1" data-path="src/pages/HealthPage.tsx">Image already uploaded. Upload new image to replace.</p>
                }
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMortalityDialog(false)}>Cancel</Button>
            <Button onClick={saveMortalityRecord}>{editingMortality ? 'Update Record' : 'Save Record'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

};

export default HealthPage;