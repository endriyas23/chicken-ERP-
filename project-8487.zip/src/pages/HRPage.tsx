import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, UserPlus, Calendar } from 'lucide-react';

const HRPage: React.FC = () => {
  return (
    <div className="space-y-6" data-id="de232zzkg" data-path="src/pages/HRPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="e1vridbjs" data-path="src/pages/HRPage.tsx">
        <div data-id="m0tden5io" data-path="src/pages/HRPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="airqsv3pa" data-path="src/pages/HRPage.tsx">HR & Payroll</h1>
          <p className="text-muted-foreground" data-id="l7fbyzd2m" data-path="src/pages/HRPage.tsx">
            Manage employees, attendance, and payroll
          </p>
        </div>
        <div className="flex gap-2" data-id="p9597maxj" data-path="src/pages/HRPage.tsx">
          <Button variant="outline">
            <Calendar size={16} className="mr-2" />
            Schedule Shifts
          </Button>
          <Button>
            <UserPlus size={16} className="mr-2" />
            Add Employee
          </Button>
        </div>
      </div>

      <Tabs defaultValue="employees">
        <TabsList>
          <TabsTrigger value="employees">Employees</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="payroll">Payroll</TabsTrigger>
          <TabsTrigger value="settings">HR Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="employees" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Employee Management</CardTitle>
              <CardDescription>
                View and manage all farm employees
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="f7s0yl669" data-path="src/pages/HRPage.tsx">
                <p className="text-muted-foreground" data-id="cu7rxrs2l" data-path="src/pages/HRPage.tsx">Employee records table will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="attendance" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Attendance Tracking</CardTitle>
              <CardDescription>
                Monitor employee attendance and work hours
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="tig0dw1o1" data-path="src/pages/HRPage.tsx">
                <p className="text-muted-foreground" data-id="wtxlaeixk" data-path="src/pages/HRPage.tsx">Attendance records will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="payroll" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Payroll Management</CardTitle>
              <CardDescription>
                Process and track employee salaries
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="b9hqexs8t" data-path="src/pages/HRPage.tsx">
                <p className="text-muted-foreground" data-id="buf3ht4z3" data-path="src/pages/HRPage.tsx">Payroll records will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>HR Settings</CardTitle>
              <CardDescription>
                Configure HR policies and settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="apeutp2st" data-path="src/pages/HRPage.tsx">
                <p className="text-muted-foreground" data-id="040ba1lyg" data-path="src/pages/HRPage.tsx">HR settings will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

export default HRPage;