import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, PlusCircle, Trash2, Edit, Search, RotateCcw } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

const FeedPage: React.FC = () => {
  const { toast } = useToast();
  // States for feed inventory
  const [feedInventory, setFeedInventory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [feedConsumption, setFeedConsumption] = useState<any[]>([]);
  const [consumptionLoading, setConsumptionLoading] = useState(false);
  const [inventoryDialog, setInventoryDialog] = useState(false);
  const [consumptionDialog, setConsumptionDialog] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [consumptionPage, setConsumptionPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [totalConsumptionItems, setTotalConsumptionItems] = useState(0);
  const pageSize = 10;

  // Form state for new feed inventory
  const [newFeed, setNewFeed] = useState({
    feed_name: '',
    category: 'layer',
    quantity_kg: 0,
    unit_price: 0,
    supplier: '',
    purchase_date: new Date(),
    expiry_date: new Date(new Date().setMonth(new Date().getMonth() + 6)),
    reorder_level: 100,
    notes: ''
  });

  // Form state for new consumption record
  const [newConsumption, setNewConsumption] = useState({
    flock_id: '',
    feed_name: '',
    consumption_date: new Date(),
    quantity_kg: 0,
    recorded_by: '',
    notes: ''
  });

  // State for available flocks (for dropdown)
  const [flocksList, setFlocksList] = useState<any[]>([]);
  const [editingFeed, setEditingFeed] = useState<any>(null);
  const [editingConsumption, setEditingConsumption] = useState<any>(null);

  // Load feed inventory data
  const loadFeedInventory = async () => {
    setLoading(true);
    try {
      const response = await window.ezsite.apis.tablePage(5004, {
        PageNo: currentPage,
        PageSize: pageSize,
        OrderByField: "purchase_date",
        IsAsc: false
      });

      if (response.error) throw response.error;

      setFeedInventory(response.data.List);
      setTotalItems(response.data.VirtualCount);
    } catch (error) {
      console.error('Error loading feed inventory:', error);
      toast({
        title: 'Error',
        description: `Failed to load feed inventory: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  // Load consumption data
  const loadFeedConsumption = async () => {
    setConsumptionLoading(true);
    try {
      const response = await window.ezsite.apis.tablePage(5005, {
        PageNo: consumptionPage,
        PageSize: pageSize,
        OrderByField: "consumption_date",
        IsAsc: false
      });

      if (response.error) throw response.error;

      setFeedConsumption(response.data.List);
      setTotalConsumptionItems(response.data.VirtualCount);
    } catch (error) {
      console.error('Error loading feed consumption:', error);
      toast({
        title: 'Error',
        description: `Failed to load consumption records: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setConsumptionLoading(false);
    }
  };

  // Load flocks for dropdown
  const loadFlocks = async () => {
    try {
      const response = await window.ezsite.apis.tablePage(5003, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: "arrival_date",
        IsAsc: false,
        Filters: [
        {
          name: "status",
          op: "Equal",
          value: "active"
        }]

      });

      if (response.error) throw response.error;
      setFlocksList(response.data.List);
    } catch (error) {
      console.error('Error loading flocks:', error);
      toast({
        title: 'Error',
        description: `Failed to load flocks: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Add or update feed inventory
  const saveFeedInventory = async () => {
    try {
      let response;

      if (editingFeed) {
        response = await window.ezsite.apis.tableUpdate(5004, {
          ...newFeed,
          ID: editingFeed.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5004, newFeed);
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingFeed ? 'Feed updated successfully' : 'New feed added to inventory'
      });

      setInventoryDialog(false);
      setEditingFeed(null);
      resetFeedForm();
      loadFeedInventory();
    } catch (error) {
      console.error('Error saving feed inventory:', error);
      toast({
        title: 'Error',
        description: `Failed to save feed inventory: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Add or update consumption record
  const saveConsumption = async () => {
    try {
      let response;

      if (editingConsumption) {
        response = await window.ezsite.apis.tableUpdate(5005, {
          ...newConsumption,
          ID: editingConsumption.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5005, newConsumption);
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingConsumption ? 'Consumption record updated' : 'Consumption record added'
      });

      setConsumptionDialog(false);
      setEditingConsumption(null);
      resetConsumptionForm();
      loadFeedConsumption();
      loadFeedInventory(); // Refresh inventory after consumption is added
    } catch (error) {
      console.error('Error saving consumption record:', error);
      toast({
        title: 'Error',
        description: `Failed to save consumption record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete feed inventory item
  const deleteFeedItem = async (id: number) => {
    if (!confirm('Are you sure you want to delete this feed inventory item?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5004, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Feed inventory item deleted'
      });

      loadFeedInventory();
    } catch (error) {
      console.error('Error deleting feed item:', error);
      toast({
        title: 'Error',
        description: `Failed to delete feed item: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete consumption record
  const deleteConsumption = async (id: number) => {
    if (!confirm('Are you sure you want to delete this consumption record?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5005, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Consumption record deleted'
      });

      loadFeedConsumption();
      loadFeedInventory(); // Refresh inventory counts
    } catch (error) {
      console.error('Error deleting consumption record:', error);
      toast({
        title: 'Error',
        description: `Failed to delete consumption record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Form reset functions
  const resetFeedForm = () => {
    setNewFeed({
      feed_name: '',
      category: 'layer',
      quantity_kg: 0,
      unit_price: 0,
      supplier: '',
      purchase_date: new Date(),
      expiry_date: new Date(new Date().setMonth(new Date().getMonth() + 6)),
      reorder_level: 100,
      notes: ''
    });
  };

  const resetConsumptionForm = () => {
    setNewConsumption({
      flock_id: '',
      feed_name: '',
      consumption_date: new Date(),
      quantity_kg: 0,
      recorded_by: '',
      notes: ''
    });
  };

  // Edit functions
  const editFeed = (feed: any) => {
    setEditingFeed(feed);
    setNewFeed({
      feed_name: feed.feed_name,
      category: feed.category,
      quantity_kg: feed.quantity_kg,
      unit_price: feed.unit_price,
      supplier: feed.supplier,
      purchase_date: new Date(feed.purchase_date),
      expiry_date: new Date(feed.expiry_date),
      reorder_level: feed.reorder_level,
      notes: feed.notes || ''
    });
    setInventoryDialog(true);
  };

  const editConsumption = (consumption: any) => {
    setEditingConsumption(consumption);
    setNewConsumption({
      flock_id: consumption.flock_id,
      feed_name: consumption.feed_name,
      consumption_date: new Date(consumption.consumption_date),
      quantity_kg: consumption.quantity_kg,
      recorded_by: consumption.recorded_by,
      notes: consumption.notes || ''
    });
    setConsumptionDialog(true);
  };

  // Handle form input changes
  const handleFeedInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewFeed((prev) => ({
      ...prev,
      [name]: name === 'quantity_kg' || name === 'unit_price' || name === 'reorder_level' ?
      parseFloat(value) || 0 :
      value
    }));
  };

  const handleConsumptionInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewConsumption((prev) => ({
      ...prev,
      [name]: name === 'quantity_kg' ? parseFloat(value) || 0 : value
    }));
  };

  // Handle date changes
  const handleDateChange = (date: Date | undefined, dateField: string) => {
    if (!date) return;
    setNewFeed((prev) => ({
      ...prev,
      [dateField]: date
    }));
  };

  const handleConsumptionDateChange = (date: Date | undefined) => {
    if (!date) return;
    setNewConsumption((prev) => ({
      ...prev,
      consumption_date: date
    }));
  };

  // Load data on initial render and when page changes
  useEffect(() => {
    loadFeedInventory();
    loadFlocks();
  }, [currentPage]);

  useEffect(() => {
    loadFeedConsumption();
  }, [consumptionPage]);

  return (
    <div className="space-y-6" data-id="asxrsyuw7" data-path="src/pages/FeedPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="vdn6aprjh" data-path="src/pages/FeedPage.tsx">
        <div data-id="8ussj7xhe" data-path="src/pages/FeedPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="mixl7r4nq" data-path="src/pages/FeedPage.tsx">Feed & Nutrition</h1>
          <p className="text-muted-foreground" data-id="v6so2q6ar" data-path="src/pages/FeedPage.tsx">
            Manage feed inventory and consumption records
          </p>
        </div>
        <div className="flex gap-2" data-id="nk054e7zp" data-path="src/pages/FeedPage.tsx">
          <Button onClick={() => {
            resetFeedForm();
            setEditingFeed(null);
            setInventoryDialog(true);
          }}>
            <PlusCircle size={16} className="mr-2" />
            Add Feed Purchase
          </Button>
          <Button variant="outline" onClick={() => {
            resetConsumptionForm();
            setEditingConsumption(null);
            setConsumptionDialog(true);
          }}>
            <PlusCircle size={16} className="mr-2" />
            Record Consumption
          </Button>
        </div>
      </div>

      <Tabs defaultValue="inventory">
        <TabsList>
          <TabsTrigger value="inventory">Feed Inventory</TabsTrigger>
          <TabsTrigger value="consumption">Consumption Records</TabsTrigger>
          <TabsTrigger value="analytics">Feed Analytics</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inventory" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="93puvpzjw" data-path="src/pages/FeedPage.tsx">
                <CardTitle>Feed Inventory</CardTitle>
                <CardDescription>
                  Current feed stock and inventory levels
                </CardDescription>
              </div>
              <div className="flex items-center gap-2" data-id="rchs3azwn" data-path="src/pages/FeedPage.tsx">
                <div className="relative w-full sm:w-64" data-id="xsr391k4k" data-path="src/pages/FeedPage.tsx">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search feeds..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" onClick={loadFeedInventory}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loading ?
              <div className="h-96 flex items-center justify-center" data-id="ct62l2ucn" data-path="src/pages/FeedPage.tsx">
                  <p data-id="g1awmobet" data-path="src/pages/FeedPage.tsx">Loading inventory data...</p>
                </div> :
              feedInventory.length === 0 ?
              <div className="h-64 flex items-center justify-center border rounded-md" data-id="4bzuv85bj" data-path="src/pages/FeedPage.tsx">
                  <p className="text-muted-foreground" data-id="zce4lzavf" data-path="src/pages/FeedPage.tsx">No feed inventory records found</p>
                </div> :

              <div className="rounded-md border" data-id="e14g23hsq" data-path="src/pages/FeedPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Feed Name</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Quantity (kg)</TableHead>
                        <TableHead className="hidden md:table-cell">Stock Level</TableHead>
                        <TableHead className="hidden md:table-cell">Unit Price</TableHead>
                        <TableHead className="hidden md:table-cell">Supplier</TableHead>
                        <TableHead>Expiry Date</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {feedInventory.map((feed) => {
                      const stockPercentage = feed.quantity_kg / feed.reorder_level * 100;
                      let stockStatus = "bg-green-500";
                      if (stockPercentage <= 25) stockStatus = "bg-red-500";else
                      if (stockPercentage <= 50) stockStatus = "bg-yellow-500";

                      return (
                        <TableRow key={feed.ID}>
                            <TableCell className="font-medium">{feed.feed_name}</TableCell>
                            <TableCell>{feed.category}</TableCell>
                            <TableCell>{feed.quantity_kg.toFixed(2)} kg</TableCell>
                            <TableCell className="hidden md:table-cell">
                              <div className="flex items-center gap-2" data-id="der8m5a53" data-path="src/pages/FeedPage.tsx">
                                <Progress value={stockPercentage} className="h-2 w-24" indicatorClassName={stockStatus} />
                                <span className="text-xs" data-id="h2mu2zout" data-path="src/pages/FeedPage.tsx">{stockPercentage.toFixed(0)}%</span>
                              </div>
                            </TableCell>
                            <TableCell className="hidden md:table-cell">${feed.unit_price.toFixed(2)}</TableCell>
                            <TableCell className="hidden md:table-cell">{feed.supplier}</TableCell>
                            <TableCell>{new Date(feed.expiry_date).toLocaleDateString()}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2" data-id="t6wewvvsz" data-path="src/pages/FeedPage.tsx">
                                <Button variant="ghost" size="icon" onClick={() => editFeed(feed)}>
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="icon" onClick={() => deleteFeedItem(feed.ID)}>
                                  <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>);

                    })}
                    </TableBody>
                  </Table>
                  <div className="flex items-center justify-center py-4" data-id="zlsevxj06" data-path="src/pages/FeedPage.tsx">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                          className={currentPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                        {[...Array(Math.min(5, Math.ceil(totalItems / pageSize)))].map((_, i) => {
                        const pageNumber = i + 1;
                        const isCurrentPage = pageNumber === currentPage;
                        return (
                          <PaginationItem key={i}>
                              <PaginationLink
                              isActive={isCurrentPage}
                              onClick={() => setCurrentPage(pageNumber)}
                              className="cursor-pointer">

                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>);

                      })}
                        {Math.ceil(totalItems / pageSize) > 5 &&
                      <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                      }
                        <PaginationItem>
                          <PaginationNext
                          onClick={() => setCurrentPage((p) => Math.min(Math.ceil(totalItems / pageSize), p + 1))}
                          className={currentPage >= Math.ceil(totalItems / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="consumption" className="space-y-4 mt-6">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
              <div data-id="zy8pl95sw" data-path="src/pages/FeedPage.tsx">
                <CardTitle>Feed Consumption</CardTitle>
                <CardDescription>
                  Track daily feed consumption by flock
                </CardDescription>
              </div>
              <div className="flex items-center gap-2" data-id="34zfd9a2d" data-path="src/pages/FeedPage.tsx">
                <div className="relative w-full sm:w-64" data-id="zki4d4gu5" data-path="src/pages/FeedPage.tsx">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search records..." className="pl-8" />
                </div>
                <Button variant="outline" size="icon" onClick={loadFeedConsumption}>
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {consumptionLoading ?
              <div className="h-96 flex items-center justify-center" data-id="n99uj1dpy" data-path="src/pages/FeedPage.tsx">
                  <p data-id="8uyw4jyyq" data-path="src/pages/FeedPage.tsx">Loading consumption data...</p>
                </div> :
              feedConsumption.length === 0 ?
              <div className="h-64 flex items-center justify-center border rounded-md" data-id="potxhjjuo" data-path="src/pages/FeedPage.tsx">
                  <p className="text-muted-foreground" data-id="8r0w0v361" data-path="src/pages/FeedPage.tsx">No feed consumption records found</p>
                </div> :

              <div className="rounded-md border" data-id="fufumf0ss" data-path="src/pages/FeedPage.tsx">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Flock ID</TableHead>
                        <TableHead>Feed Type</TableHead>
                        <TableHead>Quantity (kg)</TableHead>
                        <TableHead className="hidden md:table-cell">Recorded By</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {feedConsumption.map((consumption) =>
                    <TableRow key={consumption.ID}>
                          <TableCell>{new Date(consumption.consumption_date).toLocaleDateString()}</TableCell>
                          <TableCell>{consumption.flock_id}</TableCell>
                          <TableCell>{consumption.feed_name}</TableCell>
                          <TableCell>{consumption.quantity_kg.toFixed(2)} kg</TableCell>
                          <TableCell className="hidden md:table-cell">{consumption.recorded_by}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2" data-id="0tbn4dqxc" data-path="src/pages/FeedPage.tsx">
                              <Button variant="ghost" size="icon" onClick={() => editConsumption(consumption)}>
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => deleteConsumption(consumption.ID)}>
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                    )}
                    </TableBody>
                  </Table>
                  <div className="flex items-center justify-center py-4" data-id="v8yoiw23k" data-path="src/pages/FeedPage.tsx">
                    <Pagination>
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                          onClick={() => setConsumptionPage((p) => Math.max(1, p - 1))}
                          className={consumptionPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                        {[...Array(Math.min(5, Math.ceil(totalConsumptionItems / pageSize)))].map((_, i) => {
                        const pageNumber = i + 1;
                        const isCurrentPage = pageNumber === consumptionPage;
                        return (
                          <PaginationItem key={i}>
                              <PaginationLink
                              isActive={isCurrentPage}
                              onClick={() => setConsumptionPage(pageNumber)}
                              className="cursor-pointer">

                                {pageNumber}
                              </PaginationLink>
                            </PaginationItem>);

                      })}
                        {Math.ceil(totalConsumptionItems / pageSize) > 5 &&
                      <PaginationItem>
                            <PaginationEllipsis />
                          </PaginationItem>
                      }
                        <PaginationItem>
                          <PaginationNext
                          onClick={() => setConsumptionPage((p) => Math.min(Math.ceil(totalConsumptionItems / pageSize), p + 1))}
                          className={consumptionPage >= Math.ceil(totalConsumptionItems / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  </div>
                </div>
              }
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="analytics" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Feed Analytics</CardTitle>
              <CardDescription>
                Feed consumption trends and analysis
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4" data-id="jyoh6jywo" data-path="src/pages/FeedPage.tsx">
                <div className="border rounded-md p-4" data-id="ddwb0h44n" data-path="src/pages/FeedPage.tsx">
                  <h3 className="text-lg font-medium mb-2" data-id="z5znrl24f" data-path="src/pages/FeedPage.tsx">Monthly Feed Consumption</h3>
                  <div className="h-64 flex items-center justify-center" data-id="7wysgsjhz" data-path="src/pages/FeedPage.tsx">
                    <p className="text-muted-foreground" data-id="m4xarfuqb" data-path="src/pages/FeedPage.tsx">Feed consumption chart will be displayed here</p>
                  </div>
                </div>
                <div className="border rounded-md p-4" data-id="yj0i0f6yz" data-path="src/pages/FeedPage.tsx">
                  <h3 className="text-lg font-medium mb-2" data-id="7dyhfht01" data-path="src/pages/FeedPage.tsx">Feed Cost Analysis</h3>
                  <div className="h-64 flex items-center justify-center" data-id="adsyph3qw" data-path="src/pages/FeedPage.tsx">
                    <p className="text-muted-foreground" data-id="yj3gkq88h" data-path="src/pages/FeedPage.tsx">Feed cost chart will be displayed here</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Feed Inventory Dialog */}
      <Dialog open={inventoryDialog} onOpenChange={setInventoryDialog}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>{editingFeed ? 'Edit Feed Inventory' : 'Add New Feed'}</DialogTitle>
            <DialogDescription>
              {editingFeed ? 'Update feed inventory details' : 'Add a new feed to your inventory'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="ad4esniqw" data-path="src/pages/FeedPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="xaeasl768" data-path="src/pages/FeedPage.tsx">
              <div className="col-span-2" data-id="lc6cb0h9k" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="feed_name">Feed Name</Label>
                <Input id="feed_name" name="feed_name" value={newFeed.feed_name} onChange={handleFeedInputChange} className="mt-1" />
              </div>
              <div data-id="e5ke1gk9n" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="category">Category</Label>
                <Select value={newFeed.category} onValueChange={(value) => setNewFeed((prev) => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="starter">Starter</SelectItem>
                    <SelectItem value="grower">Grower</SelectItem>
                    <SelectItem value="layer">Layer</SelectItem>
                    <SelectItem value="finisher">Finisher</SelectItem>
                    <SelectItem value="supplement">Supplement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div data-id="22a067cyb" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="quantity_kg">Quantity (kg)</Label>
                <Input type="number" id="quantity_kg" name="quantity_kg" value={newFeed.quantity_kg} onChange={handleFeedInputChange} className="mt-1" />
              </div>
              <div data-id="1fqaovn71" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="unit_price">Unit Price</Label>
                <Input type="number" id="unit_price" name="unit_price" value={newFeed.unit_price} onChange={handleFeedInputChange} className="mt-1" />
              </div>
              <div data-id="9h6yzlddg" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="supplier">Supplier</Label>
                <Input id="supplier" name="supplier" value={newFeed.supplier} onChange={handleFeedInputChange} className="mt-1" />
              </div>
              <div data-id="t7bwgqykf" data-path="src/pages/FeedPage.tsx">
                <Label>Purchase Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newFeed.purchase_date ? format(newFeed.purchase_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newFeed.purchase_date} onSelect={(date) => handleDateChange(date, 'purchase_date')} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="vraz33yt9" data-path="src/pages/FeedPage.tsx">
                <Label>Expiry Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newFeed.expiry_date ? format(newFeed.expiry_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newFeed.expiry_date} onSelect={(date) => handleDateChange(date, 'expiry_date')} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="gmqd1wl2y" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="reorder_level">Reorder Level (kg)</Label>
                <Input type="number" id="reorder_level" name="reorder_level" value={newFeed.reorder_level} onChange={handleFeedInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="1d7u2e1qs" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Input id="notes" name="notes" value={newFeed.notes} onChange={handleFeedInputChange} className="mt-1" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setInventoryDialog(false)}>Cancel</Button>
            <Button onClick={saveFeedInventory}>{editingFeed ? 'Update Feed' : 'Add Feed'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Feed Consumption Dialog */}
      <Dialog open={consumptionDialog} onOpenChange={setConsumptionDialog}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>{editingConsumption ? 'Edit Consumption Record' : 'Add Consumption Record'}</DialogTitle>
            <DialogDescription>
              {editingConsumption ? 'Update feed consumption details' : 'Record daily feed consumption by flock'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="eorkbvywt" data-path="src/pages/FeedPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="c3zdxk9sn" data-path="src/pages/FeedPage.tsx">
              <div data-id="vsqvoihqw" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="flock_id">Flock</Label>
                <Select value={newConsumption.flock_id} onValueChange={(value) => setNewConsumption((prev) => ({ ...prev, flock_id: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select flock" />
                  </SelectTrigger>
                  <SelectContent>
                    {flocksList.map((flock) =>
                    <SelectItem key={flock.ID} value={flock.flock_id}>{flock.flock_id} - {flock.breed}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div data-id="yjq98ul97" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="feed_name">Feed Type</Label>
                <Select value={newConsumption.feed_name} onValueChange={(value) => setNewConsumption((prev) => ({ ...prev, feed_name: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select feed type" />
                  </SelectTrigger>
                  <SelectContent>
                    {feedInventory.map((feed) =>
                    <SelectItem key={feed.ID} value={feed.feed_name}>{feed.feed_name}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div data-id="so9gnrfs7" data-path="src/pages/FeedPage.tsx">
                <Label>Consumption Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newConsumption.consumption_date ? format(newConsumption.consumption_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newConsumption.consumption_date} onSelect={handleConsumptionDateChange} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="fpdihm1dz" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="quantity_kg">Quantity (kg)</Label>
                <Input type="number" id="quantity_kg" name="quantity_kg" value={newConsumption.quantity_kg} onChange={handleConsumptionInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="yd93l8u3e" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="recorded_by">Recorded By</Label>
                <Input id="recorded_by" name="recorded_by" value={newConsumption.recorded_by} onChange={handleConsumptionInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="rrzedlhgg" data-path="src/pages/FeedPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Input id="notes" name="notes" value={newConsumption.notes} onChange={handleConsumptionInputChange} className="mt-1" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConsumptionDialog(false)}>Cancel</Button>
            <Button onClick={saveConsumption}>{editingConsumption ? 'Update Record' : 'Add Record'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

};

export default FeedPage;