import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Plus, Calendar as CalendarIcon, Trash2, Edit, Search, RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Progress } from '@/components/ui/progress';

const ProductionPage: React.FC = () => {
  const { toast } = useToast();
  const [productionRecords, setProductionRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [productionDialog, setProductionDialog] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [flocksList, setFlocksList] = useState<any[]>([]);
  const [editingRecord, setEditingRecord] = useState<any>(null);
  const [todayTotal, setTodayTotal] = useState({ total: 0, flocks: 0 });
  const [qualityMetrics, setQualityMetrics] = useState({ gradeA: 0, gradeAPercent: 0 });
  const [layingRate, setLayingRate] = useState({ rate: 0, change: 0 });
  const pageSize = 10;

  // Form state for production record
  const [newRecord, setNewRecord] = useState({
    flock_id: '',
    collection_date: new Date(),
    shed_location: '',
    total_eggs: 0,
    grade_a: 0,
    grade_b: 0,
    cracked: 0,
    waste: 0,
    collected_by: '',
    notes: ''
  });

  // Load production records
  const loadProductionRecords = async () => {
    setLoading(true);
    try {
      const response = await window.ezsite.apis.tablePage(5008, {
        PageNo: currentPage,
        PageSize: pageSize,
        OrderByField: "collection_date",
        IsAsc: false
      });

      if (response.error) throw response.error;

      setProductionRecords(response.data.List);
      setTotalItems(response.data.VirtualCount);
      calculateMetrics(response.data.List);
    } catch (error) {
      console.error('Error loading production records:', error);
      toast({
        title: 'Error',
        description: `Failed to load production records: ${error}`,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  // Calculate production metrics
  const calculateMetrics = (records: any[]) => {
    // Today's date in YYYY-MM-DD format for comparison
    const today = new Date().toISOString().split('T')[0];

    // Get today's records
    const todayRecords = records.filter((record) =>
    new Date(record.collection_date).toISOString().split('T')[0] === today
    );

    // Calculate total eggs today and unique flocks
    const totalToday = todayRecords.reduce((sum, record) => sum + record.total_eggs, 0);
    const uniqueFlocks = new Set(todayRecords.map((record) => record.flock_id)).size;

    setTodayTotal({
      total: totalToday,
      flocks: uniqueFlocks
    });

    // Calculate grade A percentage
    const totalGradeA = todayRecords.reduce((sum, record) => sum + record.grade_a, 0);
    const gradeAPercentage = totalToday > 0 ? Math.round(totalGradeA / totalToday * 100) : 0;

    setQualityMetrics({
      gradeA: totalGradeA,
      gradeAPercent: gradeAPercentage
    });

    // Calculate laying rate (mock data for now, would normally use flock size data)
    setLayingRate({
      rate: 76,
      change: 3
    });
  };

  // Load flocks for dropdown
  const loadFlocks = async () => {
    try {
      const response = await window.ezsite.apis.tablePage(5003, {
        PageNo: 1,
        PageSize: 100,
        OrderByField: "arrival_date",
        IsAsc: false,
        Filters: [
        {
          name: "status",
          op: "Equal",
          value: "active"
        }]

      });

      if (response.error) throw response.error;
      setFlocksList(response.data.List);
    } catch (error) {
      console.error('Error loading flocks:', error);
      toast({
        title: 'Error',
        description: `Failed to load flocks: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Add or update production record
  const saveProductionRecord = async () => {
    try {
      // Validate the total matches the sum of categories
      const categoriesSum = newRecord.grade_a + newRecord.grade_b + newRecord.cracked + newRecord.waste;
      if (categoriesSum !== newRecord.total_eggs) {
        toast({
          title: 'Validation Error',
          description: `The sum of egg categories (${categoriesSum}) doesn't match the total (${newRecord.total_eggs})`,
          variant: 'destructive'
        });
        return;
      }

      let response;
      if (editingRecord) {
        response = await window.ezsite.apis.tableUpdate(5008, {
          ...newRecord,
          ID: editingRecord.ID
        });
      } else {
        response = await window.ezsite.apis.tableCreate(5008, newRecord);
      }

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: editingRecord ? 'Production record updated successfully' : 'New production record added'
      });

      setProductionDialog(false);
      setEditingRecord(null);
      resetForm();
      loadProductionRecords();
    } catch (error) {
      console.error('Error saving production record:', error);
      toast({
        title: 'Error',
        description: `Failed to save production record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Delete production record
  const deleteProductionRecord = async (id: number) => {
    if (!confirm('Are you sure you want to delete this production record?')) return;

    try {
      const response = await window.ezsite.apis.tableDelete(5008, { ID: id });

      if (response.error) throw response.error;

      toast({
        title: 'Success',
        description: 'Production record deleted successfully'
      });

      loadProductionRecords();
    } catch (error) {
      console.error('Error deleting production record:', error);
      toast({
        title: 'Error',
        description: `Failed to delete production record: ${error}`,
        variant: 'destructive'
      });
    }
  };

  // Form reset function
  const resetForm = () => {
    setNewRecord({
      flock_id: '',
      collection_date: new Date(),
      shed_location: '',
      total_eggs: 0,
      grade_a: 0,
      grade_b: 0,
      cracked: 0,
      waste: 0,
      collected_by: '',
      notes: ''
    });
  };

  // Edit function
  const editRecord = (record: any) => {
    setEditingRecord(record);
    setNewRecord({
      flock_id: record.flock_id,
      collection_date: new Date(record.collection_date),
      shed_location: record.shed_location || '',
      total_eggs: record.total_eggs,
      grade_a: record.grade_a,
      grade_b: record.grade_b,
      cracked: record.cracked,
      waste: record.waste,
      collected_by: record.collected_by || '',
      notes: record.notes || ''
    });
    setProductionDialog(true);
  };

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewRecord((prev) => ({
      ...prev,
      [name]: name === 'total_eggs' || name === 'grade_a' || name === 'grade_b' || name === 'cracked' || name === 'waste' ?
      parseInt(value) || 0 :
      value
    }));
  };

  // Handle date change
  const handleDateChange = (date: Date | undefined) => {
    if (!date) return;
    setNewRecord((prev) => ({
      ...prev,
      collection_date: date
    }));
  };

  // Load data on initial render and when page changes
  useEffect(() => {
    loadProductionRecords();
  }, [currentPage]);

  useEffect(() => {
    loadFlocks();
  }, []);

  // Auto-calculate total eggs when categories change
  useEffect(() => {
    const total = newRecord.grade_a + newRecord.grade_b + newRecord.cracked + newRecord.waste;
    setNewRecord((prev) => ({
      ...prev,
      total_eggs: total
    }));
  }, [newRecord.grade_a, newRecord.grade_b, newRecord.cracked, newRecord.waste]);

  return (
    <div className="space-y-6" data-id="pyutpz1bz" data-path="src/pages/ProductionPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="z6czz7fvm" data-path="src/pages/ProductionPage.tsx">
        <div data-id="s82tjdywj" data-path="src/pages/ProductionPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="n5lm0iy18" data-path="src/pages/ProductionPage.tsx">Egg Production</h1>
          <p className="text-muted-foreground" data-id="nykkstfgh" data-path="src/pages/ProductionPage.tsx">
            Monitor and manage egg collection and classification
          </p>
        </div>
        <Button onClick={() => {
          resetForm();
          setEditingRecord(null);
          setProductionDialog(true);
        }}>
          <Plus size={16} className="mr-2" />
          Add Production Record
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="3k70lrj88" data-path="src/pages/ProductionPage.tsx">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Today's Production</CardTitle>
            <CardDescription>Total eggs collected today</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="zrldkmh1x" data-path="src/pages/ProductionPage.tsx">
              <span className="text-4xl font-bold text-primary" data-id="gi688f5eg" data-path="src/pages/ProductionPage.tsx">{todayTotal.total.toLocaleString()}</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="dop2rs36j" data-path="src/pages/ProductionPage.tsx">From {todayTotal.flocks} flocks</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Grade A</CardTitle>
            <CardDescription>Quality distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="bclrx89si" data-path="src/pages/ProductionPage.tsx">
              <span className="text-4xl font-bold text-green-600" data-id="zhha37zxz" data-path="src/pages/ProductionPage.tsx">{qualityMetrics.gradeAPercent}%</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="6l6slv0bd" data-path="src/pages/ProductionPage.tsx">{qualityMetrics.gradeA.toLocaleString()} eggs</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Laying Rate</CardTitle>
            <CardDescription>Current production efficiency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="fujahtuak" data-path="src/pages/ProductionPage.tsx">
              <span className="text-4xl font-bold text-amber-600" data-id="bg0cuwfb9" data-path="src/pages/ProductionPage.tsx">{layingRate.rate}%</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="fmwtvw9j2" data-path="src/pages/ProductionPage.tsx">
                {layingRate.change > 0 ? '+' : ''}{layingRate.change}% from last week
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between sm:items-center space-y-2 sm:space-y-0">
          <div data-id="lhp3gqtvr" data-path="src/pages/ProductionPage.tsx">
            <CardTitle>Production Records</CardTitle>
            <CardDescription>
              Daily egg collection and classification data
            </CardDescription>
          </div>
          <div className="flex items-center gap-2" data-id="awfk6aqfg" data-path="src/pages/ProductionPage.tsx">
            <div className="relative w-full sm:w-64" data-id="kjdommqrw" data-path="src/pages/ProductionPage.tsx">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search records..." className="pl-8" />
            </div>
            <Button variant="outline" size="icon" onClick={loadProductionRecords}>
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ?
          <div className="h-96 flex items-center justify-center" data-id="bvkdalmac" data-path="src/pages/ProductionPage.tsx">
              <p data-id="qpqu3uu0d" data-path="src/pages/ProductionPage.tsx">Loading production records...</p>
            </div> :
          productionRecords.length === 0 ?
          <div className="h-64 flex items-center justify-center border rounded-md" data-id="u3to3tohu" data-path="src/pages/ProductionPage.tsx">
              <p className="text-muted-foreground" data-id="gynotxhm8" data-path="src/pages/ProductionPage.tsx">No production records found</p>
            </div> :

          <div className="rounded-md border" data-id="f2req2jhb" data-path="src/pages/ProductionPage.tsx">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Flock ID</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Total Eggs</TableHead>
                    <TableHead className="hidden md:table-cell">Grade A</TableHead>
                    <TableHead className="hidden md:table-cell">Grade B</TableHead>
                    <TableHead className="hidden md:table-cell">Waste</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {productionRecords.map((record) => {
                  const gradeAPercent = record.total_eggs > 0 ?
                  record.grade_a / record.total_eggs * 100 :
                  0;

                  return (
                    <TableRow key={record.ID}>
                        <TableCell>{new Date(record.collection_date).toLocaleDateString()}</TableCell>
                        <TableCell>{record.flock_id}</TableCell>
                        <TableCell>{record.shed_location}</TableCell>
                        <TableCell className="font-medium">{record.total_eggs}</TableCell>
                        <TableCell className="hidden md:table-cell">
                          <div className="flex items-center gap-2" data-id="hnne8en6s" data-path="src/pages/ProductionPage.tsx">
                            <Progress value={gradeAPercent} className="h-2 w-16" />
                            <span data-id="76wxainum" data-path="src/pages/ProductionPage.tsx">{record.grade_a} ({Math.round(gradeAPercent)}%)</span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">{record.grade_b}</TableCell>
                        <TableCell className="hidden md:table-cell">{record.cracked + record.waste}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2" data-id="bpqh33fa5" data-path="src/pages/ProductionPage.tsx">
                            <Button variant="ghost" size="icon" onClick={() => editRecord(record)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => deleteProductionRecord(record.ID)}>
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>);

                })}
                </TableBody>
              </Table>
              <div className="flex items-center justify-center py-4" data-id="tefzantkw" data-path="src/pages/ProductionPage.tsx">
                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className={currentPage <= 1 ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                    </PaginationItem>
                    {[...Array(Math.min(5, Math.ceil(totalItems / pageSize)))].map((_, i) => {
                    const pageNumber = i + 1;
                    const isCurrentPage = pageNumber === currentPage;
                    return (
                      <PaginationItem key={i}>
                          <PaginationLink
                          isActive={isCurrentPage}
                          onClick={() => setCurrentPage(pageNumber)}
                          className="cursor-pointer">

                            {pageNumber}
                          </PaginationLink>
                        </PaginationItem>);

                  })}
                    {Math.ceil(totalItems / pageSize) > 5 &&
                  <PaginationItem>
                        <PaginationEllipsis />
                      </PaginationItem>
                  }
                    <PaginationItem>
                      <PaginationNext
                      onClick={() => setCurrentPage((p) => Math.min(Math.ceil(totalItems / pageSize), p + 1))}
                      className={currentPage >= Math.ceil(totalItems / pageSize) ? "pointer-events-none opacity-50" : "cursor-pointer"} />

                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
            </div>
          }
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Production Trends</CardTitle>
          <CardDescription>
            Egg production trends over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80 flex items-center justify-center border rounded-md" data-id="6gk5vkiah" data-path="src/pages/ProductionPage.tsx">
            <p className="text-muted-foreground" data-id="32o3jtvxs" data-path="src/pages/ProductionPage.tsx">Production trend chart will be displayed here</p>
          </div>
        </CardContent>
      </Card>

      {/* Production Record Dialog */}
      <Dialog open={productionDialog} onOpenChange={setProductionDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>{editingRecord ? 'Edit Production Record' : 'Add New Production Record'}</DialogTitle>
            <DialogDescription>
              {editingRecord ? 'Update production record details' : 'Record daily egg collection data'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4" data-id="vp4pzro2x" data-path="src/pages/ProductionPage.tsx">
            <div className="grid grid-cols-2 gap-4" data-id="as2u0cboh" data-path="src/pages/ProductionPage.tsx">
              <div data-id="lbjozo8wq" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="flock_id">Flock</Label>
                <Select value={newRecord.flock_id} onValueChange={(value) => setNewRecord((prev) => ({ ...prev, flock_id: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select flock" />
                  </SelectTrigger>
                  <SelectContent>
                    {flocksList.map((flock) =>
                    <SelectItem key={flock.ID} value={flock.flock_id}>{flock.flock_id} - {flock.breed}</SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>
              <div data-id="iz41742dv" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="shed_location">Shed/Location</Label>
                <Input id="shed_location" name="shed_location" value={newRecord.shed_location} onChange={handleInputChange} className="mt-1" />
              </div>
              <div data-id="b30944jw3" data-path="src/pages/ProductionPage.tsx">
                <Label>Collection Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal mt-1">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {newRecord.collection_date ? format(newRecord.collection_date, 'PPP') : "Select date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar mode="single" selected={newRecord.collection_date} onSelect={handleDateChange} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
              <div data-id="jhxkvxox1" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="collected_by">Collected By</Label>
                <Input id="collected_by" name="collected_by" value={newRecord.collected_by} onChange={handleInputChange} className="mt-1" />
              </div>
              <div data-id="se5v4v7ra" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="grade_a">Grade A Eggs</Label>
                <Input type="number" id="grade_a" name="grade_a" value={newRecord.grade_a} onChange={handleInputChange} className="mt-1" />
              </div>
              <div data-id="t4wmq4zer" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="grade_b">Grade B Eggs</Label>
                <Input type="number" id="grade_b" name="grade_b" value={newRecord.grade_b} onChange={handleInputChange} className="mt-1" />
              </div>
              <div data-id="a76j6ibo8" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="cracked">Cracked Eggs</Label>
                <Input type="number" id="cracked" name="cracked" value={newRecord.cracked} onChange={handleInputChange} className="mt-1" />
              </div>
              <div data-id="zw24xmiw0" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="waste">Waste/Rejected</Label>
                <Input type="number" id="waste" name="waste" value={newRecord.waste} onChange={handleInputChange} className="mt-1" />
              </div>
              <div className="col-span-2" data-id="conkw2yn3" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="total_eggs">Total Eggs</Label>
                <Input
                  type="number"
                  id="total_eggs"
                  name="total_eggs"
                  value={newRecord.total_eggs}
                  onChange={handleInputChange}
                  disabled
                  className="mt-1 bg-muted" />

                <p className="text-xs text-muted-foreground mt-1" data-id="26v17ht4t" data-path="src/pages/ProductionPage.tsx">
                  Total is automatically calculated from the categories above
                </p>
              </div>
              <div className="col-span-2" data-id="u94oiih0c" data-path="src/pages/ProductionPage.tsx">
                <Label htmlFor="notes">Notes</Label>
                <Input id="notes" name="notes" value={newRecord.notes} onChange={handleInputChange} className="mt-1" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProductionDialog(false)}>Cancel</Button>
            <Button onClick={saveProductionRecord}>{editingRecord ? 'Update Record' : 'Save Record'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>);

};

export default ProductionPage;