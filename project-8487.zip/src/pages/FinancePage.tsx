import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, Download } from 'lucide-react';

const FinancePage: React.FC = () => {
  return (
    <div className="space-y-6" data-id="27ear8nq3" data-path="src/pages/FinancePage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="buek42f67" data-path="src/pages/FinancePage.tsx">
        <div data-id="zoozej2uf" data-path="src/pages/FinancePage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="b3pgue3s2" data-path="src/pages/FinancePage.tsx">Finance & Accounting</h1>
          <p className="text-muted-foreground" data-id="ulakobpfr" data-path="src/pages/FinancePage.tsx">
            Manage income, expenses, and financial reports
          </p>
        </div>
        <div className="flex gap-2" data-id="qgmrbn3bq" data-path="src/pages/FinancePage.tsx">
          <Button variant="outline">
            <Download size={16} className="mr-2" />
            Export Reports
          </Button>
          <Button>
            <Plus size={16} className="mr-2" />
            Record Expense
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="vx9e7ni3d" data-path="src/pages/FinancePage.tsx">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Monthly Income</CardTitle>
            <CardDescription>Total income this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="3tlxlm8k5" data-path="src/pages/FinancePage.tsx">
              <span className="text-4xl font-bold text-green-600" data-id="ue5ayyswz" data-path="src/pages/FinancePage.tsx">$25,680</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="abaj1bq5x" data-path="src/pages/FinancePage.tsx">+12% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Monthly Expenses</CardTitle>
            <CardDescription>Total expenses this month</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="na100dhtj" data-path="src/pages/FinancePage.tsx">
              <span className="text-4xl font-bold text-red-600" data-id="1j3u4pfb8" data-path="src/pages/FinancePage.tsx">$16,240</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="pg5y07xrh" data-path="src/pages/FinancePage.tsx">+5% from last month</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Net Profit</CardTitle>
            <CardDescription>Monthly profit margin</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="2fztyn931" data-path="src/pages/FinancePage.tsx">
              <span className="text-4xl font-bold text-blue-600" data-id="ccpd85tps" data-path="src/pages/FinancePage.tsx">$9,440</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="pfjc20i93" data-path="src/pages/FinancePage.tsx">36.7% margin</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="expenses">
        <TabsList>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="income">Income</TabsTrigger>
          <TabsTrigger value="reports">Financial Reports</TabsTrigger>
        </TabsList>
        
        <TabsContent value="expenses" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Expense Tracking</CardTitle>
              <CardDescription>
                Monitor and categorize all farm expenses
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="uxhd94g93" data-path="src/pages/FinancePage.tsx">
                <p className="text-muted-foreground" data-id="rt5rrabtw" data-path="src/pages/FinancePage.tsx">Expense records table will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="income" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Income Records</CardTitle>
              <CardDescription>
                Track all sources of income
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="txgkigke5" data-path="src/pages/FinancePage.tsx">
                <p className="text-muted-foreground" data-id="wraee8a2l" data-path="src/pages/FinancePage.tsx">Income records table will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="reports" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Financial Reports</CardTitle>
              <CardDescription>
                Generate and view financial reports
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="e5oqoysv3" data-path="src/pages/FinancePage.tsx">
                <p className="text-muted-foreground" data-id="09ejuume1" data-path="src/pages/FinancePage.tsx">Financial reports will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

export default FinancePage;