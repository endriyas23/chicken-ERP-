import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue } from
'@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Save } from 'lucide-react';

const SettingsPage: React.FC = () => {
  return (
    <div className="space-y-6" data-id="o13hil6k4" data-path="src/pages/SettingsPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="imvl2rr4g" data-path="src/pages/SettingsPage.tsx">
        <div data-id="1j6rhxoou" data-path="src/pages/SettingsPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="1v8tlh1lz" data-path="src/pages/SettingsPage.tsx">Settings</h1>
          <p className="text-muted-foreground" data-id="9hzexv0a8" data-path="src/pages/SettingsPage.tsx">
            Configure system settings and preferences
          </p>
        </div>
      </div>

      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="users">Users & Permissions</TabsTrigger>
          <TabsTrigger value="farm">Farm Setup</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>
                Basic system configuration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4" data-id="spo08q8s3" data-path="src/pages/SettingsPage.tsx">
                <div className="space-y-2" data-id="h3u0dgb8b" data-path="src/pages/SettingsPage.tsx">
                  <Label htmlFor="farm_name">Farm Name</Label>
                  <Input id="farm_name" placeholder="Enter farm name" defaultValue="Green Valley Poultry Farm" />
                </div>
                
                <div className="space-y-2" data-id="b6vmhsmc2" data-path="src/pages/SettingsPage.tsx">
                  <Label htmlFor="timezone">Timezone</Label>
                  <Select defaultValue="utc">
                    <SelectTrigger id="timezone">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="utc">UTC (Coordinated Universal Time)</SelectItem>
                      <SelectItem value="est">EST (Eastern Standard Time)</SelectItem>
                      <SelectItem value="cst">CST (Central Standard Time)</SelectItem>
                      <SelectItem value="pst">PST (Pacific Standard Time)</SelectItem>
                      <SelectItem value="eet">EET (Eastern European Time)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2" data-id="ioste329o" data-path="src/pages/SettingsPage.tsx">
                  <Label htmlFor="language">Language</Label>
                  <Select defaultValue="en">
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="am">Amharic</SelectItem>
                      <SelectItem value="fr">French</SelectItem>
                      <SelectItem value="es">Spanish</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2" data-id="3er2lfc5g" data-path="src/pages/SettingsPage.tsx">
                  <Label htmlFor="currency">Currency</Label>
                  <Select defaultValue="usd">
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="usd">USD ($)</SelectItem>
                      <SelectItem value="etb">ETB (Br)</SelectItem>
                      <SelectItem value="eur">EUR (€)</SelectItem>
                      <SelectItem value="gbp">GBP (£)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center justify-between" data-id="enzr694m5" data-path="src/pages/SettingsPage.tsx">
                  <div className="space-y-0.5" data-id="btlzr7sdu" data-path="src/pages/SettingsPage.tsx">
                    <Label htmlFor="dark_mode">Dark Mode</Label>
                    <p className="text-sm text-muted-foreground" data-id="a1nx5g9q7" data-path="src/pages/SettingsPage.tsx">
                      Enable dark theme
                    </p>
                  </div>
                  <Switch id="dark_mode" />
                </div>
                
                <div className="flex items-center justify-between" data-id="749hewnya" data-path="src/pages/SettingsPage.tsx">
                  <div className="space-y-0.5" data-id="t6o552d9x" data-path="src/pages/SettingsPage.tsx">
                    <Label htmlFor="notifications">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground" data-id="jkt8c3h8s" data-path="src/pages/SettingsPage.tsx">
                      Receive system notifications via email
                    </p>
                  </div>
                  <Switch id="notifications" defaultChecked />
                </div>
              </div>
              
              <Button>
                <Save size={16} className="mr-2" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="users" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Users & Permissions</CardTitle>
              <CardDescription>
                Manage system users and access controls
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 flex items-center justify-center border rounded-md" data-id="6tugnfwbs" data-path="src/pages/SettingsPage.tsx">
                <p className="text-muted-foreground" data-id="vc13cpsbt" data-path="src/pages/SettingsPage.tsx">User management panel will be displayed here</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="farm" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Farm Setup</CardTitle>
              <CardDescription>
                Configure farm-specific settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6" data-id="1uzv3vw3g" data-path="src/pages/SettingsPage.tsx">
                <div className="space-y-4" data-id="kai38ytuk" data-path="src/pages/SettingsPage.tsx">
                  <div className="space-y-2" data-id="6jxmetuxu" data-path="src/pages/SettingsPage.tsx">
                    <Label htmlFor="shed_count">Number of Sheds</Label>
                    <Input id="shed_count" type="number" defaultValue="6" />
                  </div>
                  
                  <div className="space-y-2" data-id="407p4mljf" data-path="src/pages/SettingsPage.tsx">
                    <Label htmlFor="farm_capacity">Total Farm Capacity</Label>
                    <Input id="farm_capacity" type="number" defaultValue="10000" />
                  </div>
                  
                  <div className="space-y-2" data-id="iiaoom033" data-path="src/pages/SettingsPage.tsx">
                    <Label htmlFor="farm_type">Farm Type</Label>
                    <Select defaultValue="mixed">
                      <SelectTrigger id="farm_type">
                        <SelectValue placeholder="Select farm type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="layer">Layer Farm</SelectItem>
                        <SelectItem value="broiler">Broiler Farm</SelectItem>
                        <SelectItem value="mixed">Mixed Farm</SelectItem>
                        <SelectItem value="breeding">Breeding Farm</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <Button>
                  <Save size={16} className="mr-2" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure alerts and notification preferences
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6" data-id="uylypkfxe" data-path="src/pages/SettingsPage.tsx">
                <div className="space-y-4" data-id="89vkal78r" data-path="src/pages/SettingsPage.tsx">
                  <div className="flex items-center justify-between" data-id="2iqbm83z1" data-path="src/pages/SettingsPage.tsx">
                    <div className="space-y-0.5" data-id="i1ki87vxm" data-path="src/pages/SettingsPage.tsx">
                      <Label>Low Feed Stock Alerts</Label>
                      <p className="text-sm text-muted-foreground" data-id="yri6n2dnc" data-path="src/pages/SettingsPage.tsx">
                        Notify when feed stock is below threshold
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between" data-id="et4hpgk4h" data-path="src/pages/SettingsPage.tsx">
                    <div className="space-y-0.5" data-id="xk92829wr" data-path="src/pages/SettingsPage.tsx">
                      <Label>Mortality Rate Alerts</Label>
                      <p className="text-sm text-muted-foreground" data-id="4h4n8ul01" data-path="src/pages/SettingsPage.tsx">
                        Notify when mortality rate exceeds threshold
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between" data-id="svvy2viva" data-path="src/pages/SettingsPage.tsx">
                    <div className="space-y-0.5" data-id="a934miio5" data-path="src/pages/SettingsPage.tsx">
                      <Label>Vaccination Reminders</Label>
                      <p className="text-sm text-muted-foreground" data-id="cwbup33xn" data-path="src/pages/SettingsPage.tsx">
                        Send reminders for upcoming vaccinations
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between" data-id="besw4tax0" data-path="src/pages/SettingsPage.tsx">
                    <div className="space-y-0.5" data-id="giogk5gf5" data-path="src/pages/SettingsPage.tsx">
                      <Label>Order Notifications</Label>
                      <p className="text-sm text-muted-foreground" data-id="hbi1gp7ts" data-path="src/pages/SettingsPage.tsx">
                        Notify when new orders are placed
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between" data-id="vhxv2rtbg" data-path="src/pages/SettingsPage.tsx">
                    <div className="space-y-0.5" data-id="ztfagjcmg" data-path="src/pages/SettingsPage.tsx">
                      <Label>Financial Alerts</Label>
                      <p className="text-sm text-muted-foreground" data-id="jqsebcvbo" data-path="src/pages/SettingsPage.tsx">
                        Send alerts for unusual financial activity
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
                
                <Button>
                  <Save size={16} className="mr-2" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>);

};

export default SettingsPage;