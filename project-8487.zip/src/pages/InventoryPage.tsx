import React from 'react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

const InventoryPage: React.FC = () => {
  return (
    <div className="space-y-6" data-id="epjox82st" data-path="src/pages/InventoryPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="rhk8pl23q" data-path="src/pages/InventoryPage.tsx">
        <div data-id="b9nrd0exs" data-path="src/pages/InventoryPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="6f6av45ep" data-path="src/pages/InventoryPage.tsx">Inventory Management</h1>
          <p className="text-muted-foreground" data-id="it5ceftzo" data-path="src/pages/InventoryPage.tsx">
            Track and manage all farm inventory items
          </p>
        </div>
        <Button>
          <Plus size={16} className="mr-2" />
          Add Inventory Item
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4" data-id="6ung98t41" data-path="src/pages/InventoryPage.tsx">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Feed Stock</CardTitle>
            <CardDescription>Current feed inventory</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="vyj8u41zr" data-path="src/pages/InventoryPage.tsx">
              <span className="text-4xl font-bold text-primary" data-id="rdzxvicth" data-path="src/pages/InventoryPage.tsx">1,200 kg</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="0oxzovdz2" data-path="src/pages/InventoryPage.tsx">3 different types</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Medicine</CardTitle>
            <CardDescription>Available medicines</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="ircg83azs" data-path="src/pages/InventoryPage.tsx">
              <span className="text-4xl font-bold text-indigo-600" data-id="9ynj7k7jg" data-path="src/pages/InventoryPage.tsx">23</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="jelxmv0mk" data-path="src/pages/InventoryPage.tsx">Items in stock</span>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">Equipment</CardTitle>
            <CardDescription>Farm tools and equipment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center" data-id="bjjfbu737" data-path="src/pages/InventoryPage.tsx">
              <span className="text-4xl font-bold text-amber-600" data-id="lh6lfpmnd" data-path="src/pages/InventoryPage.tsx">42</span>
              <span className="text-sm text-muted-foreground mt-1" data-id="pwbd2xxfy" data-path="src/pages/InventoryPage.tsx">Items tracked</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Inventory Items</CardTitle>
          <CardDescription>
            Complete inventory tracking and management
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-96 flex items-center justify-center border rounded-md" data-id="8qst6csmw" data-path="src/pages/InventoryPage.tsx">
            <p className="text-muted-foreground" data-id="9iil0q30p" data-path="src/pages/InventoryPage.tsx">Inventory table will be displayed here</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-id="gs1wyxe37" data-path="src/pages/InventoryPage.tsx">
        <Card>
          <CardHeader>
            <CardTitle>Low Stock Items</CardTitle>
            <CardDescription>
              Items below reorder level
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center border rounded-md" data-id="wf070c5y2" data-path="src/pages/InventoryPage.tsx">
              <p className="text-muted-foreground" data-id="va4ydaz2m" data-path="src/pages/InventoryPage.tsx">Low stock alerts will be displayed here</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Expiring Items</CardTitle>
            <CardDescription>
              Items expiring soon
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center border rounded-md" data-id="1o9f4jetu" data-path="src/pages/InventoryPage.tsx">
              <p className="text-muted-foreground" data-id="hbgj2bi3k" data-path="src/pages/InventoryPage.tsx">Expiry alerts will be displayed here</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>);

};

export default InventoryPage;