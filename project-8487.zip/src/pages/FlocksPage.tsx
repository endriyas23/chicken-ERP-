import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow } from
'@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger } from
'@/components/ui/dialog';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle } from
'@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue } from
'@/components/ui/select';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious } from
"@/components/ui/pagination";
import { CalendarIcon, Plus, Search } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

// Flock interface
interface Flock {
  ID: number;
  flock_id: string;
  breed: string;
  flock_type: string;
  quantity: number;
  arrival_date: string;
  shed_location: string;
  source: string;
  status: string;
  notes: string;
}

const FlocksPage: React.FC = () => {
  const { toast } = useToast();
  const [flocks, setFlocks] = useState<Flock[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const pageSize = 10;

  // Form state for new flock
  const [newFlock, setNewFlock] = useState({
    flock_id: '',
    breed: '',
    flock_type: 'layer',
    quantity: 0,
    arrival_date: '',
    shed_location: '',
    source: '',
    status: 'active',
    notes: ''
  });
  const [arrivalDate, setArrivalDate] = useState<Date | undefined>(undefined);

  useEffect(() => {
    fetchFlocks();
  }, [currentPage, searchTerm]);

  const fetchFlocks = async () => {
    try {
      setLoading(true);

      // Mock data for development purposes
      await new Promise((resolve) => setTimeout(resolve, 800)); // Simulate network delay

      const mockFlocks: Flock[] = [
      {
        ID: 1,
        flock_id: 'F-2023-01',
        breed: 'Rhode Island Red',
        flock_type: 'layer',
        quantity: 1200,
        arrival_date: '2023-01-15',
        shed_location: 'Shed A',
        source: 'ABC Hatchery',
        status: 'active',
        notes: 'Healthy flock with good production'
      },
      {
        ID: 2,
        flock_id: 'F-2023-02',
        breed: 'Leghorn',
        flock_type: 'layer',
        quantity: 950,
        arrival_date: '2023-02-10',
        shed_location: 'Shed B',
        source: 'XYZ Farms',
        status: 'active',
        notes: 'Showing good growth'
      },
      {
        ID: 3,
        flock_id: 'F-2023-03',
        breed: 'Broiler',
        flock_type: 'broiler',
        quantity: 2000,
        arrival_date: '2023-03-05',
        shed_location: 'Shed C',
        source: 'Best Chicks Inc',
        status: 'active',
        notes: 'Fast growing batch'
      },
      {
        ID: 4,
        flock_id: 'F-2022-12',
        breed: 'Plymouth Rock',
        flock_type: 'dual',
        quantity: 800,
        arrival_date: '2022-12-20',
        shed_location: 'Shed D',
        source: 'Quality Poultry',
        status: 'sold',
        notes: 'Sold to Restaurant Chain'
      },
      {
        ID: 5,
        flock_id: 'F-2022-11',
        breed: 'Sussex',
        flock_type: 'layer',
        quantity: 1100,
        arrival_date: '2022-11-05',
        shed_location: 'Shed E',
        source: 'Premium Hatchery',
        status: 'completed',
        notes: 'Completed production cycle'
      }];


      // Apply search filtering if term exists
      let filteredFlocks = mockFlocks;
      if (searchTerm) {
        filteredFlocks = mockFlocks.filter((flock) =>
        flock.flock_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        flock.breed.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }

      setFlocks(filteredFlocks);
      setTotalPages(Math.ceil(filteredFlocks.length / pageSize));

      // Real API implementation (commented out for now)
      /*
      // Prepare filters
      const filters = [];
      if (searchTerm) {
        filters.push({
          name: "flock_id",
          op: "StringContains",
          value: searchTerm
        });
      }
      
      const response = await window.ezsite.apis.tablePage(5003, {
        PageNo: currentPage,
        PageSize: pageSize,
        OrderByField: "arrival_date",
        IsAsc: false,
        Filters: filters
      });
      
      if (response.error) {
        throw new Error(response.error);
      }
      
      setFlocks(response.data.List);
      setTotalPages(Math.ceil(response.data.VirtualCount / pageSize));
      */
    } catch (error) {
      console.error('Error fetching flocks:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load flocks. Please try again."
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewFlock({
      ...newFlock,
      [name]: name === 'quantity' ? parseInt(value) || 0 : value
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setNewFlock({
      ...newFlock,
      [name]: value
    });
  };

  const handleDateChange = (date: Date | undefined) => {
    setArrivalDate(date);
    if (date) {
      setNewFlock({
        ...newFlock,
        arrival_date: format(date, 'yyyy-MM-dd')
      });
    }
  };

  const handleAddFlock = async () => {
    try {
      // Mock adding a flock for development purposes
      await new Promise((resolve) => setTimeout(resolve, 800)); // Simulate network delay

      // Close dialog and refresh data
      setIsAddDialogOpen(false);
      fetchFlocks();

      // Reset form
      setNewFlock({
        flock_id: '',
        breed: '',
        flock_type: 'layer',
        quantity: 0,
        arrival_date: '',
        shed_location: '',
        source: '',
        status: 'active',
        notes: ''
      });
      setArrivalDate(undefined);

      toast({
        title: "Success",
        description: "Flock added successfully"
      });

      // Real API implementation (commented out for now)
      /*
      const response = await window.ezsite.apis.tableCreate(5003, newFlock);
      
      if (response.error) {
        throw new Error(response.error);
      }
      
      // Close dialog and refresh data
      setIsAddDialogOpen(false);
      fetchFlocks();
      
      // Reset form
      setNewFlock({
        flock_id: '',
        breed: '',
        flock_type: 'layer',
        quantity: 0,
        arrival_date: '',
        shed_location: '',
        source: '',
        status: 'active',
        notes: ''
      });
      setArrivalDate(undefined);
      
      toast({
        title: "Success",
        description: "Flock added successfully",
      });
      */
    } catch (error) {
      console.error('Error adding flock:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to add flock. Please try again."
      });
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    try {
      const date = new Date(dateString);
      return format(date, 'MMM dd, yyyy');
    } catch {
      return dateString;
    }
  };

  return (
    <div className="space-y-6" data-id="b5o0v2hmx" data-path="src/pages/FlocksPage.tsx">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4" data-id="dg08ay4jm" data-path="src/pages/FlocksPage.tsx">
        <div data-id="a824gyzhd" data-path="src/pages/FlocksPage.tsx">
          <h1 className="text-3xl font-bold tracking-tight" data-id="1lll0m0vj" data-path="src/pages/FlocksPage.tsx">Flocks</h1>
          <p className="text-muted-foreground" data-id="uo0iaeep5" data-path="src/pages/FlocksPage.tsx">
            Manage your chicken flocks and track their details
          </p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus size={16} className="mr-2" />
              Add New Flock
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Flock</DialogTitle>
              <DialogDescription>
                Enter the details of the new flock.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4" data-id="zoafin4lk" data-path="src/pages/FlocksPage.tsx">
              <div className="grid grid-cols-4 items-center gap-4" data-id="oglf3jywd" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="flock_id" className="text-right">
                  Flock ID
                </Label>
                <Input
                  id="flock_id"
                  name="flock_id"
                  value={newFlock.flock_id}
                  onChange={handleInputChange}
                  className="col-span-3"
                  placeholder="e.g., F-2023-01" />

              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="jy52asczs" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="breed" className="text-right">
                  Breed
                </Label>
                <Input
                  id="breed"
                  name="breed"
                  value={newFlock.breed}
                  onChange={handleInputChange}
                  className="col-span-3"
                  placeholder="e.g., Rhode Island Red" />

              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="6b4geisft" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="flock_type" className="text-right">
                  Type
                </Label>
                <Select
                  value={newFlock.flock_type}
                  onValueChange={(value) => handleSelectChange('flock_type', value)}>

                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select flock type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="layer">Layer</SelectItem>
                    <SelectItem value="broiler">Broiler</SelectItem>
                    <SelectItem value="dual">Dual Purpose</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="js8bxaap9" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="quantity" className="text-right">
                  Quantity
                </Label>
                <Input
                  id="quantity"
                  name="quantity"
                  type="number"
                  value={newFlock.quantity.toString()}
                  onChange={handleInputChange}
                  className="col-span-3"
                  placeholder="Number of birds" />

              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="buo99si68" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="arrival_date" className="text-right">
                  Arrival Date
                </Label>
                <div className="col-span-3" data-id="2os2tpm78" data-path="src/pages/FlocksPage.tsx">
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !arrivalDate && "text-muted-foreground"
                        )}>

                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {arrivalDate ? format(arrivalDate, "PPP") : <span data-id="rub1026xz" data-path="src/pages/FlocksPage.tsx">Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={arrivalDate}
                        onSelect={handleDateChange}
                        initialFocus />

                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="flaezvhlg" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="shed_location" className="text-right">
                  Shed Location
                </Label>
                <Input
                  id="shed_location"
                  name="shed_location"
                  value={newFlock.shed_location}
                  onChange={handleInputChange}
                  className="col-span-3"
                  placeholder="e.g., Shed A" />

              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="33b6gdjdb" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="source" className="text-right">
                  Source
                </Label>
                <Input
                  id="source"
                  name="source"
                  value={newFlock.source}
                  onChange={handleInputChange}
                  className="col-span-3"
                  placeholder="e.g., ABC Hatchery" />

              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="d0doh40ih" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="status" className="text-right">
                  Status
                </Label>
                <Select
                  value={newFlock.status}
                  onValueChange={(value) => handleSelectChange('status', value)}>

                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="sold">Sold</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4" data-id="ys5juvwb9" data-path="src/pages/FlocksPage.tsx">
                <Label htmlFor="notes" className="text-right">
                  Notes
                </Label>
                <Input
                  id="notes"
                  name="notes"
                  value={newFlock.notes}
                  onChange={handleInputChange}
                  className="col-span-3"
                  placeholder="Additional notes" />

              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddFlock}>Add Flock</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Flock Management</CardTitle>
          <CardDescription>
            View and manage all your chicken flocks
          </CardDescription>
          <div className="flex flex-col sm:flex-row gap-4 mt-4" data-id="a7sh6s1k7" data-path="src/pages/FlocksPage.tsx">
            <div className="relative w-full sm:w-72" data-id="c164yl3a6" data-path="src/pages/FlocksPage.tsx">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search flocks..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)} />

            </div>
            <Select defaultValue="all">
              <SelectTrigger className="w-full sm:w-36">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="sold">Sold</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-full sm:w-36">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="layer">Layer</SelectItem>
                <SelectItem value="broiler">Broiler</SelectItem>
                <SelectItem value="dual">Dual Purpose</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          {loading ?
          <div className="flex justify-center py-8" data-id="cutkdgo2h" data-path="src/pages/FlocksPage.tsx">
              <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary" data-id="cbrnjdnb6" data-path="src/pages/FlocksPage.tsx"></div>
            </div> :

          <>
              <div className="rounded-md border" data-id="x8wi4ep07" data-path="src/pages/FlocksPage.tsx">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Flock ID</TableHead>
                      <TableHead>Breed</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Arrival Date</TableHead>
                      <TableHead>Shed</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {flocks.length === 0 ?
                  <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No flocks found. Add a new flock to get started.
                        </TableCell>
                      </TableRow> :

                  flocks.map((flock) =>
                  <TableRow key={flock.ID}>
                          <TableCell className="font-medium">{flock.flock_id}</TableCell>
                          <TableCell>{flock.breed}</TableCell>
                          <TableCell className="capitalize">{flock.flock_type}</TableCell>
                          <TableCell>{flock.quantity}</TableCell>
                          <TableCell>{formatDate(flock.arrival_date)}</TableCell>
                          <TableCell>{flock.shed_location}</TableCell>
                          <TableCell>
                            <span className={cn(
                        "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium",
                        flock.status === 'active' && "bg-green-100 text-green-800",
                        flock.status === 'sold' && "bg-blue-100 text-blue-800",
                        flock.status === 'completed' && "bg-gray-100 text-gray-800"
                      )} data-id="w8tq3337k" data-path="src/pages/FlocksPage.tsx">
                              {flock.status.charAt(0).toUpperCase() + flock.status.slice(1)}
                            </span>
                          </TableCell>
                        </TableRow>
                  )
                  }
                  </TableBody>
                </Table>
              </div>
              
              {totalPages > 1 &&
            <div className="mt-4 flex justify-center" data-id="r23n88fck" data-path="src/pages/FlocksPage.tsx">
                  <Pagination>
                    <PaginationContent>
                      <PaginationItem>
                        <PaginationPrevious
                      onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1} />

                      </PaginationItem>
                      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) =>
                  <PaginationItem key={page}>
                          <PaginationLink
                      isActive={currentPage === page}
                      onClick={() => setCurrentPage(page)}>

                            {page}
                          </PaginationLink>
                        </PaginationItem>
                  )}
                      <PaginationItem>
                        <PaginationNext
                      onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages} />

                      </PaginationItem>
                    </PaginationContent>
                  </Pagination>
                </div>
            }
            </>
          }
        </CardContent>
      </Card>
    </div>);

};

export default FlocksPage;